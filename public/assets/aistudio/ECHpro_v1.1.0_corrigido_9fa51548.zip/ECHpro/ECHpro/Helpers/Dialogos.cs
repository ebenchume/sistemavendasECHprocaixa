using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace ECHpro.Helpers
{
    public class CampoForm
    {
        public string Rotulo { get; set; } = "";
        public string Valor { get; set; } = "";
        public bool EhSenha { get; set; }
        /// <summary>Se preenchido, o campo é uma lista de escolha em vez de texto livre.</summary>
        public IList<string>? Opcoes { get; set; }
    }

    /// <summary>Janelas de formulário simples, construídas em código, partilhadas pelos ecrãs.</summary>
    public static class Dialogos
    {
        private static readonly Brush Vinho = new SolidColorBrush(Color.FromRgb(107, 0, 0));

        /// <summary>
        /// Mostra um formulário e devolve os valores pela ordem dos campos, ou null se cancelado.
        /// A função "validar" pode devolver uma mensagem de erro para manter o formulário aberto.
        /// </summary>
        public static string[]? Formulario(Window? owner, string titulo, string textoBotao,
            IList<CampoForm> campos, Func<string[], string?>? validar = null, double largura = 430)
        {
            var dlg = new Window
            {
                Title = titulo,
                Width = largura,
                SizeToContent = SizeToContent.Height,
                MaxHeight = SystemParameters.WorkArea.Height * 0.92,
                WindowStartupLocation = owner != null ? WindowStartupLocation.CenterOwner : WindowStartupLocation.CenterScreen,
                Owner = owner,
                ResizeMode = ResizeMode.NoResize,
                ShowInTaskbar = false,
                Background = Brushes.White
            };

            var painel = new StackPanel { Margin = new Thickness(20) };
            var controlos = new List<Control>();

            foreach (var campo in campos)
            {
                painel.Children.Add(new TextBlock
                {
                    Text = campo.Rotulo,
                    Margin = new Thickness(0, 8, 0, 2),
                    FontSize = 12,
                    Foreground = Brushes.DimGray
                });

                Control ctl;
                if (campo.Opcoes != null)
                {
                    var cmb = new ComboBox { Height = 34, Padding = new Thickness(8, 6, 8, 6), FontSize = 14 };
                    foreach (var o in campo.Opcoes) cmb.Items.Add(o);
                    cmb.SelectedItem = campo.Opcoes.Contains(campo.Valor)
                        ? campo.Valor
                        : (campo.Opcoes.Count > 0 ? campo.Opcoes[0] : null);
                    ctl = cmb;
                }
                else if (campo.EhSenha)
                {
                    ctl = new PasswordBox { Height = 34, Padding = new Thickness(8, 6, 8, 6), FontSize = 14 };
                }
                else
                {
                    ctl = new TextBox { Text = campo.Valor, Height = 34, Padding = new Thickness(8, 6, 8, 6), FontSize = 14 };
                }
                painel.Children.Add(ctl);
                controlos.Add(ctl);
            }

            var erro = new TextBlock
            {
                Foreground = new SolidColorBrush(Color.FromRgb(198, 40, 40)),
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(0, 12, 0, 0),
                Visibility = Visibility.Collapsed
            };
            painel.Children.Add(erro);

            var botoes = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 16, 0, 0) };
            var btnCancelar = new Button { Content = "Cancelar", Width = 100, Height = 38, Margin = new Thickness(0, 0, 10, 0), IsCancel = true };
            var btnOk = new Button
            {
                Content = textoBotao,
                Width = 120,
                Height = 38,
                IsDefault = true,
                Background = Vinho,
                Foreground = Brushes.White,
                BorderThickness = new Thickness(0)
            };
            botoes.Children.Add(btnCancelar);
            botoes.Children.Add(btnOk);
            painel.Children.Add(botoes);

            string[]? resultado = null;

            btnOk.Click += (s, e) =>
            {
                var valores = controlos.Select(ObterValor).ToArray();
                var msg = validar?.Invoke(valores);
                if (!string.IsNullOrEmpty(msg))
                {
                    erro.Text = msg;
                    erro.Visibility = Visibility.Visible;
                    return;
                }
                resultado = valores;
                dlg.DialogResult = true;
            };

            dlg.Content = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Content = painel };
            dlg.Loaded += (s, e) => { if (controlos.Count > 0) controlos[0].Focus(); };
            dlg.ShowDialog();
            return resultado;
        }

        private static string ObterValor(Control c) => c switch
        {
            TextBox t => t.Text,
            PasswordBox p => p.Password,
            ComboBox cb => cb.SelectedItem?.ToString() ?? "",
            _ => ""
        };

        public static void Info(string mensagem, string titulo = "ECHpro")
            => MessageBox.Show(mensagem, titulo, MessageBoxButton.OK, MessageBoxImage.Information);

        public static void Aviso(string mensagem, string titulo = "ECHpro")
            => MessageBox.Show(mensagem, titulo, MessageBoxButton.OK, MessageBoxImage.Warning);

        public static void Erro(string mensagem, string titulo = "ECHpro - Erro")
            => MessageBox.Show(mensagem, titulo, MessageBoxButton.OK, MessageBoxImage.Error);

        public static bool Confirmar(string mensagem, string titulo = "Confirmar")
            => MessageBox.Show(mensagem, titulo, MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes;
    }
}
