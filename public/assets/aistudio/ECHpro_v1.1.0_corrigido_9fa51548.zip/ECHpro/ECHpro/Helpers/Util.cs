using System.Globalization;
using System.IO;

namespace ECHpro.Helpers
{
    /// <summary>Funções utilitárias partilhadas (números, moeda, erros).</summary>
    public static class Util
    {
        /// <summary>
        /// Converte texto digitado pelo utilizador em decimal, aceitando "1234,50", "1234.50",
        /// "1.234,50" e "1,234.50". O separador decimal é o último que aparecer.
        /// </summary>
        public static bool TryParseDecimal(string? texto, out decimal valor)
        {
            valor = 0;
            if (string.IsNullOrWhiteSpace(texto)) return false;

            var s = texto.Trim()
                         .Replace("MZN", "", StringComparison.OrdinalIgnoreCase)
                         .Replace(" ", "")
                         .Replace("\u00A0", "")
                         .Replace("\u202F", "");

            int ultimaVirgula = s.LastIndexOf(',');
            int ultimoPonto = s.LastIndexOf('.');

            if (ultimaVirgula >= 0 && ultimoPonto >= 0)
            {
                if (ultimaVirgula > ultimoPonto) s = s.Replace(".", "").Replace(',', '.');
                else s = s.Replace(",", "");
            }
            else if (ultimaVirgula >= 0)
            {
                if (s.IndexOf(',') != ultimaVirgula) s = s.Replace(",", "");   // várias vírgulas = milhares
                else s = s.Replace(',', '.');
            }
            else if (ultimoPonto >= 0 && s.IndexOf('.') != ultimoPonto)
            {
                s = s.Replace(".", "");                                        // vários pontos = milhares
            }

            return decimal.TryParse(s,
                NumberStyles.AllowLeadingSign | NumberStyles.AllowDecimalPoint,
                CultureInfo.InvariantCulture, out valor);
        }

        public static decimal ParseDecimal(string? texto, decimal padrao = 0)
            => TryParseDecimal(texto, out var v) ? v : padrao;

        /// <summary>Número para edição em caixas de texto (sem separador de milhares).</summary>
        public static string Editavel(decimal valor) => valor.ToString("0.##", CultureInfo.CurrentCulture);

        public static string Moeda(decimal valor) => $"{valor:N2} MZN";

        /// <summary>Lê datas guardadas na base de dados (yyyy-MM-dd HH:mm:ss) sem depender da cultura.</summary>
        public static DateTime? ParseData(string? texto)
        {
            if (string.IsNullOrWhiteSpace(texto)) return null;
            return DateTime.TryParse(texto, CultureInfo.InvariantCulture, DateTimeStyles.None, out var d) ? d : null;
        }

        public static string FormatoBD(DateTime d) => d.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);

        /// <summary>Regista erros num ficheiro de log em %LocalAppData%\ECHpro\logs.</summary>
        public static void Log(Exception ex, string contexto = "")
        {
            try
            {
                var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "ECHpro", "logs");
                Directory.CreateDirectory(dir);
                var ficheiro = Path.Combine(dir, $"erro_{DateTime.Now:yyyyMMdd}.log");
                File.AppendAllText(ficheiro,
                    $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {contexto}\n{ex}\n\n");
            }
            catch { /* o log nunca deve causar outro erro */ }
        }

        /// <summary>Verdadeiro se for violação de restrição UNIQUE/FOREIGN KEY do SQLite.</summary>
        public static bool EErroDeRestricao(Exception ex)
            => ex is Microsoft.Data.Sqlite.SqliteException sx && sx.SqliteErrorCode == 19;
    }
}
