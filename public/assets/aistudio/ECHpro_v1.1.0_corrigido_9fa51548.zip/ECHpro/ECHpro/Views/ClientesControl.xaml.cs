using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using ECHpro.Helpers;
using ECHpro.Models;
using ECHpro.Services;

namespace ECHpro.Views
{
    public partial class ClientesControl : UserControl
    {
        private readonly ClienteService _service = new();
        private readonly VendaService _vendaService = new();
        private readonly int _utilizadorId;

        public ClientesControl(int utilizadorId)
        {
            InitializeComponent();
            _utilizadorId = utilizadorId;
            Loaded += (s, e) => Carregar();
        }

        private void Carregar(string? termo = null)
        {
            GridClientes.ItemsSource = _service.Pesquisar(termo ?? "", 200);
        }

        private void BtnPesquisar_Click(object sender, RoutedEventArgs e) => Carregar(TxtPesquisa.Text);
        private void TxtPesquisa_KeyDown(object sender, KeyEventArgs e) { if (e.Key == Key.Enter) Carregar(TxtPesquisa.Text); }

        private void BtnNovo_Click(object sender, RoutedEventArgs e)
        {
            var c = MostrarDialogoCliente(new Cliente());
            if (c != null && Gravar(c)) Carregar();
        }

        private void GridClientes_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (GridClientes.SelectedItem is Cliente cli)
            {
                var editado = MostrarDialogoCliente(cli);
                if (editado != null && Gravar(editado)) Carregar();
            }
        }

        private bool Gravar(Cliente c)
        {
            try
            {
                _service.Guardar(c);
                return true;
            }
            catch (Exception ex)
            {
                Util.Log(ex, "GuardarCliente");
                Dialogos.Erro($"Não foi possível guardar o cliente:\n{ex.Message}");
                return false;
            }
        }

        private void BtnDesactivar_Click(object sender, RoutedEventArgs e)
        {
            if (GridClientes.SelectedItem is not Cliente cli)
            {
                Dialogos.Info("Seleccione primeiro um cliente na lista.");
                return;
            }
            if (cli.Nome == "Cliente Geral")
            {
                Dialogos.Aviso("O \"Cliente Geral\" não pode ser desactivado.");
                return;
            }
            if (cli.SaldoAberto > 0)
            {
                Dialogos.Aviso($"O cliente tem uma dívida de {Util.Moeda(cli.SaldoAberto)}.\nReceba o pagamento antes de o desactivar.");
                return;
            }
            if (!Dialogos.Confirmar($"Desactivar o cliente \"{cli.Nome}\"?")) return;

            try
            {
                _service.Desactivar(cli.Id);
                Carregar();
            }
            catch (Exception ex)
            {
                Util.Log(ex, "DesactivarCliente");
                Dialogos.Erro($"Não foi possível desactivar o cliente:\n{ex.Message}");
            }
        }

        private void BtnReceber_Click(object sender, RoutedEventArgs e)
        {
            if (GridClientes.SelectedItem is not Cliente cli)
            {
                Dialogos.Info("Seleccione primeiro um cliente na lista.");
                return;
            }
            if (cli.SaldoAberto <= 0)
            {
                Dialogos.Info("Este cliente não tem dívidas em aberto.");
                return;
            }

            // "Crédito" não faz sentido como forma de receber dinheiro
            var formas = new CaixaService().ListarFormasPagamento()
                .Where(f => !string.Equals(f.Nome, "Crédito", StringComparison.OrdinalIgnoreCase))
                .ToList();
            if (formas.Count == 0)
            {
                Dialogos.Aviso("Não existem formas de pagamento disponíveis.");
                return;
            }

            var valores = Dialogos.Formulario(Window.GetWindow(this),
                $"Receber pagamento — {cli.Nome}", "Receber",
                new List<CampoForm>
                {
                    new() { Rotulo = $"Valor recebido (dívida actual: {Util.Moeda(cli.SaldoAberto)})", Valor = Util.Editavel(cli.SaldoAberto) },
                    new() { Rotulo = "Forma de pagamento", Opcoes = formas.Select(f => f.Nome).ToList(), Valor = formas[0].Nome }
                },
                v =>
                {
                    if (!Util.TryParseDecimal(v[0], out var valor) || valor <= 0) return "Indique um valor maior que zero.";
                    if (valor > cli.SaldoAberto + 0.005m) return $"O valor não pode exceder a dívida ({Util.Moeda(cli.SaldoAberto)}).";
                    return null;
                });

            if (valores == null) return;

            try
            {
                var formaId = formas.First(f => f.Nome == valores[1]).Id;
                _vendaService.ReceberPagamento(cli.Id, Util.ParseDecimal(valores[0]), formaId, _utilizadorId);
                Dialogos.Info("Pagamento registado com sucesso.");
                Carregar();
            }
            catch (Exception ex)
            {
                Util.Log(ex, "ReceberPagamento");
                Dialogos.Erro($"Não foi possível registar o pagamento:\n{ex.Message}");
            }
        }

        private Cliente? MostrarDialogoCliente(Cliente original)
        {
            var campos = new List<CampoForm>
            {
                new() { Rotulo = "Nome *", Valor = original.Nome },
                new() { Rotulo = "NUIT", Valor = original.NUIT ?? "" },
                new() { Rotulo = "Telefone", Valor = original.Telefone ?? "" },
                new() { Rotulo = "Email", Valor = original.Email ?? "" },
                new() { Rotulo = "Cidade", Valor = original.Cidade ?? "" },
                new() { Rotulo = "Endereço", Valor = original.Endereco ?? "" }
            };

            var valores = Dialogos.Formulario(Window.GetWindow(this),
                original.Id == 0 ? "Novo Cliente" : "Editar Cliente", "Guardar", campos,
                v => string.IsNullOrWhiteSpace(v[0]) ? "O nome é obrigatório." : null);
            if (valores == null) return null;

            original.Nome = valores[0].Trim();
            original.NUIT = valores[1].Trim();
            original.Telefone = valores[2].Trim();
            original.Email = valores[3].Trim();
            original.Cidade = valores[4].Trim();
            original.Endereco = valores[5].Trim();
            return original;
        }
    }
}
