using System.Windows;
using System.Windows.Controls;
using ECHpro.Helpers;
using ECHpro.Services;

namespace ECHpro.Views
{
    public partial class CaixaControl : UserControl
    {
        private readonly CaixaService _service = new();
        private readonly int _utilizadorId;

        public CaixaControl(int utilizadorId)
        {
            InitializeComponent();
            _utilizadorId = utilizadorId;
            Loaded += (s, e) =>
            {
                DpDe.SelectedDate = DateTime.Today;
                DpAte.SelectedDate = DateTime.Today;
                Carregar();
            };
        }

        private void Carregar()
        {
            var de = DpDe.SelectedDate ?? DateTime.Today;
            var ate = DpAte.SelectedDate ?? DateTime.Today;
            var lista = _service.Listar(de, ate);
            GridCaixa.ItemsSource = lista;

            var entradas = lista.Sum(m => m.Entrada);
            var saidas = lista.Sum(m => m.Saida);
            TxtResumo.Text = $"Entradas: {Util.Moeda(entradas)}   |   Saídas: {Util.Moeda(saidas)}   |   " +
                             $"Resultado do período: {Util.Moeda(entradas - saidas)}   |   Saldo actual da caixa: {Util.Moeda(_service.SaldoActual())}";
        }

        private void BtnFiltrar_Click(object sender, RoutedEventArgs e) => Carregar();

        private void BtnHoje_Click(object sender, RoutedEventArgs e)
        {
            DpDe.SelectedDate = DateTime.Today;
            DpAte.SelectedDate = DateTime.Today;
            Carregar();
        }

        private void BtnEntrada_Click(object sender, RoutedEventArgs e) => Registar("Entrada");
        private void BtnSaida_Click(object sender, RoutedEventArgs e) => Registar("Saida");

        private void Registar(string tipo)
        {
            var formas = _service.ListarFormasPagamento();
            var nomes = formas.Select(f => f.Nome).ToList();
            var titulo = tipo == "Entrada" ? "Nova entrada de caixa" : "Nova saída de caixa";

            var valores = Dialogos.Formulario(Window.GetWindow(this), titulo, "Registar",
                new List<CampoForm>
                {
                    new() { Rotulo = "Descrição *" },
                    new() { Rotulo = "Valor (MZN) *" },
                    new() { Rotulo = "Forma de pagamento", Opcoes = nomes, Valor = nomes.FirstOrDefault() ?? "" }
                },
                v =>
                {
                    if (string.IsNullOrWhiteSpace(v[0])) return "A descrição é obrigatória.";
                    if (!Util.TryParseDecimal(v[1], out var val) || val <= 0) return "Indique um valor maior que zero.";
                    return null;
                });
            if (valores == null) return;

            try
            {
                int? formaId = formas.Any(f => f.Nome == valores[2]) ? formas.First(f => f.Nome == valores[2]).Id : null;
                _service.RegistarManual(tipo, valores[0], Util.ParseDecimal(valores[1]), formaId, _utilizadorId);
                Carregar();
            }
            catch (Exception ex)
            {
                Util.Log(ex, "MovimentoCaixa");
                Dialogos.Erro($"Não foi possível registar o movimento:\n{ex.Message}");
            }
        }
    }
}
