using System.Windows;
using System.Windows.Controls;
using ECHpro.Helpers;
using ECHpro.Services;

namespace ECHpro.Views
{
    public partial class RelatoriosControl : UserControl
    {
        private readonly RelatorioService _service = new();

        public RelatoriosControl()
        {
            InitializeComponent();
            Loaded += (s, e) =>
            {
                DpDe.SelectedDate = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
                DpAte.SelectedDate = DateTime.Today;
                Gerar();
            };
        }

        private void Gerar()
        {
            try
            {
                var de = DpDe.SelectedDate ?? DateTime.Today;
                var ate = DpAte.SelectedDate ?? DateTime.Today;
                var r = _service.ObterResumo(de, ate);
                TxtResumo.Text =
                    $"Vendas no período: {r.NumeroVendas}\n" +
                    $"Total vendido: {Util.Moeda(r.TotalVendido)}   (IVA incluído: {Util.Moeda(r.TotalIVA)})\n" +
                    $"Total recebido: {Util.Moeda(r.TotalRecebido)}   |   Por receber: {Util.Moeda(r.TotalPorReceber)}\n" +
                    $"Lucro bruto estimado (sem IVA, preço de venda − custo): {Util.Moeda(r.LucroEstimado)}";
                GridTop.ItemsSource = _service.ProdutosMaisVendidos(de, ate);
            }
            catch (Exception ex)
            {
                Util.Log(ex, "Relatorios");
                Dialogos.Erro($"Não foi possível gerar o relatório:\n{ex.Message}");
            }
        }

        private void BtnGerar_Click(object sender, RoutedEventArgs e) => Gerar();

        private void BtnMes_Click(object sender, RoutedEventArgs e)
        {
            DpDe.SelectedDate = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
            DpAte.SelectedDate = DateTime.Today;
            Gerar();
        }
    }
}
