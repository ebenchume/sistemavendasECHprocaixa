using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using ECHpro.Helpers;
using ECHpro.Services;

namespace ECHpro.Views
{
    public partial class MainWindow : Window
    {
        public int UsuarioId { get; }
        public string NomeUsuario { get; }
        public string NivelAcesso { get; }

        private readonly LicenseService _licenseService = new();
        private readonly RelatorioService _relatorioService = new();
        private readonly DispatcherTimer _timer;

        private bool EGestor => NivelAcesso == "Admin" || NivelAcesso == "Gerente";

        public MainWindow(int usuarioId, string nomeUsuario, string nivelAcesso)
        {
            InitializeComponent();
            UsuarioId = usuarioId;
            NomeUsuario = nomeUsuario;
            NivelAcesso = nivelAcesso;

            TxtUsuarioLogado.Text = nomeUsuario;
            TxtNivelAcesso.Text = nivelAcesso;

            _timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
            _timer.Tick += (s, e) => TxtDataHora.Text = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
            _timer.Start();
            TxtDataHora.Text = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");

            PreviewKeyDown += MainWindow_PreviewKeyDown;

            AtualizarBadgeLicenca();
            MostrarDashboard();
        }

        private void MainWindow_PreviewKeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (ContentArea.Content is not PDVControl pdv) return;

            if (e.Key is Key.F2 or Key.F3 or Key.F5 or Key.F8)
            {
                pdv.ProcessarAtalho(e.Key);
                e.Handled = true;
            }
            else if (e.Key == Key.Delete)
            {
                // Dentro de uma caixa de texto, Delete apaga texto; só remove o item fora delas
                var foco = Keyboard.FocusedElement;
                if (foco is not TextBox && foco is not PasswordBox)
                {
                    pdv.ProcessarAtalho(e.Key);
                    e.Handled = true;
                }
            }
        }

        private void AtualizarBadgeLicenca()
        {
            var info = _licenseService.GetLicenseInfo();
            var vermelho = new SolidColorBrush(Color.FromRgb(107, 0, 0));
            var branco = new SolidColorBrush(Color.FromRgb(255, 255, 255));

            if (info.Tipo == "Demo" && info.IsValid)
            {
                TxtBadgeLicenca.Text = $"Demo — {info.DiasRestantes}d";
                BadgeLicenca.Background = vermelho;
                TxtBadgeLicenca.Foreground = branco;
            }
            else if (info.IsValid)
            {
                TxtBadgeLicenca.Text = $"{info.Tipo} — {info.DiasRestantes}d";
                BadgeLicenca.Background = vermelho;
                TxtBadgeLicenca.Foreground = branco;
            }
            else
            {
                // Antes o texto ficava com a mesma cor do fundo e não se lia
                TxtBadgeLicenca.Text = "EXPIRADA";
                BadgeLicenca.Background = new SolidColorBrush(Color.FromRgb(255, 235, 238));
                TxtBadgeLicenca.Foreground = vermelho;
            }
        }

        private void MostrarDashboard()
        {
            TxtTituloPagina.Text = "Painel Principal";
            var panel = new StackPanel { Margin = new Thickness(0) };

            panel.Children.Add(new TextBlock
            {
                Text = $"Bem-vindo(a), {NomeUsuario}!",
                FontSize = 24,
                FontWeight = FontWeights.SemiBold,
                Foreground = new SolidColorBrush(Color.FromRgb(107, 0, 0)),
                Margin = new Thickness(0, 0, 0, 20)
            });

            panel.Children.Add(new TextBlock
            {
                Text = "Seleccione uma opção no menu lateral para começar.\n\n" +
                       "• Use o Ponto de Venda (PDV) para registar vendas rápidas\n" +
                       "• Gerencie produtos, stock e clientes\n" +
                       "• Consulte relatórios e o livro de caixa\n\n" +
                       "Atalhos no PDV: F2 = Pesquisa | F3 = Clientes | F5 = Finalizar | F8 = Limpar | Del = Remover item",
                FontSize = 14,
                Foreground = new SolidColorBrush(Color.FromRgb(84, 110, 122)),
                TextWrapping = TextWrapping.Wrap,
                LineHeight = 24
            });

            // Cards com dados reais
            ResumoPainel resumo;
            try { resumo = _relatorioService.ObterResumoPainel(); }
            catch (Exception ex)
            {
                Util.Log(ex, "Dashboard");
                resumo = new ResumoPainel();
            }

            var cards = new WrapPanel { Margin = new Thickness(0, 30, 0, 0) };
            cards.Children.Add(CriarCard("Vendas Hoje", Util.Moeda(resumo.VendasHoje), "#6B0000"));
            cards.Children.Add(CriarCard("Nº de Vendas Hoje", resumo.NumeroVendasHoje.ToString(), "#4A0000"));
            cards.Children.Add(CriarCard("Produtos", resumo.Produtos.ToString(), "#4A0000"));
            cards.Children.Add(CriarCard("Stock Baixo", resumo.StockBaixo.ToString(), resumo.StockBaixo > 0 ? "#FF6F00" : "#2E7D32"));
            cards.Children.Add(CriarCard("Clientes", resumo.Clientes.ToString(), "#2E7D32"));
            if (EGestor)
            {
                cards.Children.Add(CriarCard("Dívida de Clientes", Util.Moeda(resumo.DividaClientes), "#FF6F00"));
                cards.Children.Add(CriarCard("Saldo da Caixa", Util.Moeda(resumo.SaldoCaixa), "#2E7D32"));
            }
            panel.Children.Add(cards);

            ContentArea.Content = new ScrollViewer
            {
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                Content = panel
            };
        }

        private Border CriarCard(string titulo, string valor, string cor)
        {
            var border = new Border
            {
                Width = 230,
                Height = 110,
                Background = Brushes.White,
                CornerRadius = new CornerRadius(12),
                Margin = new Thickness(0, 0, 16, 16),
                Padding = new Thickness(20),
                Effect = new System.Windows.Media.Effects.DropShadowEffect
                {
                    BlurRadius = 10,
                    ShadowDepth = 2,
                    Opacity = 0.1
                }
            };

            var sp = new StackPanel();
            sp.Children.Add(new TextBlock
            {
                Text = titulo,
                FontSize = 13,
                Foreground = new SolidColorBrush(Color.FromRgb(120, 144, 156))
            });
            sp.Children.Add(new TextBlock
            {
                Text = valor,
                FontSize = 24,
                FontWeight = FontWeights.Bold,
                Foreground = (SolidColorBrush)new BrushConverter().ConvertFrom(cor)!,
                Margin = new Thickness(0, 8, 0, 0),
                TextTrimming = TextTrimming.CharacterEllipsis
            });
            border.Child = sp;
            return border;
        }

        private bool ExigirGestor()
        {
            if (EGestor) return true;
            MessageBox.Show("Apenas Administradores e Gerentes podem aceder a esta área.",
                "Acesso Negado", MessageBoxButton.OK, MessageBoxImage.Warning);
            return false;
        }

        private void MenuPDV_Click(object sender, RoutedEventArgs e)
        {
            if (!VerificarLicenca()) return;
            TxtTituloPagina.Text = "Ponto de Venda (PDV)";
            var pdv = new PDVControl();
            pdv.Inicializar(UsuarioId, NomeUsuario);
            pdv.VendaFinalizada += (s, args) => AtualizarBadgeLicenca();
            ContentArea.Content = pdv;
        }

        private void MenuProdutos_Click(object sender, RoutedEventArgs e)
        {
            if (!VerificarLicenca()) return;
            TxtTituloPagina.Text = "Produtos / Stock";
            ContentArea.Content = new ProdutosControl(UsuarioId);
        }

        private void MenuClientes_Click(object sender, RoutedEventArgs e)
        {
            if (!VerificarLicenca()) return;
            TxtTituloPagina.Text = "Clientes";
            ContentArea.Content = new ClientesControl(UsuarioId);
        }

        private void MenuVendas_Click(object sender, RoutedEventArgs e)
        {
            if (!VerificarLicenca()) return;
            TxtTituloPagina.Text = "Facturas / Vendas";
            ContentArea.Content = new VendasControl(UsuarioId, EGestor);
        }

        private void MenuCaixa_Click(object sender, RoutedEventArgs e)
        {
            if (!VerificarLicenca()) return;
            if (!ExigirGestor()) return;
            TxtTituloPagina.Text = "Livro de Caixa";
            ContentArea.Content = new CaixaControl(UsuarioId);
        }

        private void MenuRelatorios_Click(object sender, RoutedEventArgs e)
        {
            if (!VerificarLicenca()) return;
            if (!ExigirGestor()) return;
            TxtTituloPagina.Text = "Relatórios";
            ContentArea.Content = new RelatoriosControl();
        }

        private void MenuConfig_Click(object sender, RoutedEventArgs e)
        {
            if (!ExigirGestor()) return;
            TxtTituloPagina.Text = "Configurações";
            ContentArea.Content = new ConfigControl(UsuarioId, NivelAcesso);
        }

        private void MenuLicenca_Click(object sender, RoutedEventArgs e)
        {
            var act = new ActivationWindow { Owner = this };
            act.ShowDialog();
            AtualizarBadgeLicenca();
        }

        private void MenuSobre_Click(object sender, RoutedEventArgs e)
        {
            var info = _licenseService.GetLicenseInfo();
            MessageBox.Show(
                "ECHpro — Sistema de Gestão de Vendas e Faturação\n" +
                "Versão 1.1.0\n\n" +
                "Desenvolvido por: Eben Chume\n" +
                "Contactos de Suporte:\n" +
                "  WhatsApp / Telefone: +258 827473434\n" +
                "  Email: ebenchume@sapo.mz\n\n" +
                $"Licença: {info.Tipo}\n" +
                $"Expira em: {(info.DataExpiracao.HasValue ? info.DataExpiracao.Value.ToString("dd/MM/yyyy") : "N/A")}\n" +
                $"ID da Máquina: {info.MachineId}\n\n" +
                "© 2026 Eben Chume. Todos os direitos reservados.",
                "Sobre o ECHpro",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
        }

        private void BtnLogout_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Deseja realmente terminar a sessão?", "Terminar Sessão",
                MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (result == MessageBoxResult.Yes)
            {
                _timer.Stop();
                var login = new LoginWindow();
                Application.Current.MainWindow = login;
                login.Show();
                Close();
            }
        }

        private bool VerificarLicenca()
        {
            if (_licenseService.IsLicenseValid()) return true;

            var result = MessageBox.Show(
                "A sua licença expirou ou atingiu o limite de utilização.\n\nDeseja activar uma nova chave agora?",
                "Licença Expirada",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning);

            if (result == MessageBoxResult.Yes)
            {
                var act = new ActivationWindow { Owner = this };
                act.ShowDialog();
                AtualizarBadgeLicenca();
                return _licenseService.IsLicenseValid();
            }
            return false;
        }

        protected override void OnClosed(EventArgs e)
        {
            _timer?.Stop();
            base.OnClosed(e);
        }
    }
}
