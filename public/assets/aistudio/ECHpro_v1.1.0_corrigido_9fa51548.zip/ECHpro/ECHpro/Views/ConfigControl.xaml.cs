using System.Windows;
using System.Windows.Controls;
using ECHpro.Helpers;
using ECHpro.Services;

namespace ECHpro.Views
{
    public partial class ConfigControl : UserControl
    {
        private readonly int _utilizadorId;
        private readonly string _nivel;
        private readonly UsuarioService _usuarios = new();

        public ConfigControl(int utilizadorId, string nivel)
        {
            InitializeComponent();
            _utilizadorId = utilizadorId;
            _nivel = nivel;
            Loaded += ConfigControl_Loaded;
        }

        private void ConfigControl_Loaded(object sender, RoutedEventArgs e)
        {
            var soAdmin = _nivel == "Admin" ? Visibility.Visible : Visibility.Collapsed;
            BtnNovoUtilizador.Visibility = soAdmin;
            BtnUtilizadores.Visibility = soAdmin;

            using var conn = DatabaseService.GetConnection();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT Nome, NUIT, Endereco, Telefone, Email FROM Tbl_CadEmpresa LIMIT 1";
            using var r = cmd.ExecuteReader();
            if (r.Read())
            {
                TxtNomeEmpresa.Text = r.IsDBNull(0) ? "" : r.GetString(0);
                TxtNuit.Text = r.IsDBNull(1) ? "" : r.GetString(1);
                TxtEndereco.Text = r.IsDBNull(2) ? "" : r.GetString(2);
                TxtTelefone.Text = r.IsDBNull(3) ? "" : r.GetString(3);
                TxtEmail.Text = r.IsDBNull(4) ? "" : r.GetString(4);
            }
            TxtIVA.Text = DatabaseService.GetConfig("IVA_Percentagem", "16");
            TxtSerie.Text = DatabaseService.GetConfig("SerieFactura", "FT");
            TxtRodape.Text = DatabaseService.GetConfig("MensagemRodape", "");
        }

        private void BtnGuardar_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TxtNomeEmpresa.Text))
            {
                Dialogos.Aviso("O nome da empresa é obrigatório.");
                return;
            }
            if (!Util.TryParseDecimal(TxtIVA.Text, out var iva) || iva < 0 || iva > 100)
            {
                Dialogos.Aviso("A taxa de IVA deve ser um número entre 0 e 100.");
                return;
            }
            var serie = TxtSerie.Text.Trim().ToUpperInvariant();
            if (serie.Length == 0 || serie.Length > 6 || serie.Contains(' ') || serie.Contains('/'))
            {
                Dialogos.Aviso("A série deve ter 1 a 6 caracteres, sem espaços nem \"/\" (ex.: FT).");
                return;
            }

            try
            {
                using var conn = DatabaseService.GetConnection();
                using var cmd = conn.CreateCommand();
                cmd.CommandText = @"UPDATE Tbl_CadEmpresa SET Nome=@n, NUIT=@nuit, Endereco=@end, Telefone=@tel, Email=@email
                                    WHERE Id = (SELECT MIN(Id) FROM Tbl_CadEmpresa)";
                cmd.Parameters.AddWithValue("@n", TxtNomeEmpresa.Text.Trim());
                cmd.Parameters.AddWithValue("@nuit", TxtNuit.Text.Trim());
                cmd.Parameters.AddWithValue("@end", TxtEndereco.Text.Trim());
                cmd.Parameters.AddWithValue("@tel", TxtTelefone.Text.Trim());
                cmd.Parameters.AddWithValue("@email", TxtEmail.Text.Trim());
                cmd.ExecuteNonQuery();

                DatabaseService.SetConfig("IVA_Percentagem",
                    iva.ToString(System.Globalization.CultureInfo.InvariantCulture));
                DatabaseService.SetConfig("SerieFactura", serie);
                DatabaseService.SetConfig("MensagemRodape", TxtRodape.Text.Trim());
                TxtSerie.Text = serie;

                Dialogos.Info("Configurações guardadas com sucesso.");
            }
            catch (Exception ex)
            {
                Util.Log(ex, "GuardarConfig");
                Dialogos.Erro($"Erro: {ex.Message}");
            }
        }

        private void BtnAlterarSenha_Click(object sender, RoutedEventArgs e)
        {
            var valores = Dialogos.Formulario(Window.GetWindow(this), "Alterar senha", "Alterar",
                new List<CampoForm>
                {
                    new() { Rotulo = "Senha actual", EhSenha = true },
                    new() { Rotulo = $"Nova senha (mínimo {UsuarioService.TamanhoMinimoSenha} caracteres)", EhSenha = true },
                    new() { Rotulo = "Repetir a nova senha", EhSenha = true }
                },
                v => v[1] != v[2] ? "As senhas novas não coincidem." : null);
            if (valores == null) return;

            var (ok, msg) = _usuarios.AlterarSenha(_utilizadorId, valores[0], valores[1]);
            if (ok) Dialogos.Info(msg); else Dialogos.Aviso(msg);
        }

        private void BtnNovoUtilizador_Click(object sender, RoutedEventArgs e)
        {
            var valores = Dialogos.Formulario(Window.GetWindow(this), "Novo utilizador", "Criar",
                new List<CampoForm>
                {
                    new() { Rotulo = "Nome de utilizador (login) *" },
                    new() { Rotulo = "Nome completo *" },
                    new() { Rotulo = "Nível de acesso", Opcoes = new List<string> { "Operador", "Gerente", "Admin" }, Valor = "Operador" },
                    new() { Rotulo = $"Senha (mínimo {UsuarioService.TamanhoMinimoSenha} caracteres)", EhSenha = true }
                });
            if (valores == null) return;

            var (ok, msg) = _usuarios.Criar(valores[0], valores[1], valores[2], valores[3]);
            if (ok) Dialogos.Info(msg); else Dialogos.Aviso(msg);
        }

        private void BtnUtilizadores_Click(object sender, RoutedEventArgs e)
        {
            var lista = _usuarios.Listar();
            var nomes = lista.Select(u => $"{u.Username} ({u.Nivel}) - {(u.Activo ? "activo" : "desactivado")}").ToList();

            var valores = Dialogos.Formulario(Window.GetWindow(this), "Activar / Desactivar utilizador", "Aplicar",
                new List<CampoForm>
                {
                    new() { Rotulo = "Utilizador", Opcoes = nomes, Valor = nomes.FirstOrDefault() ?? "" },
                    new() { Rotulo = "Acção", Opcoes = new List<string> { "Desactivar", "Activar" }, Valor = "Desactivar" }
                });
            if (valores == null) return;

            var idx = nomes.IndexOf(valores[0]);
            if (idx < 0) return;
            var u = lista[idx];
            if (u.Id == _utilizadorId && valores[1] == "Desactivar")
            {
                Dialogos.Aviso("Não pode desactivar o utilizador com que iniciou sessão.");
                return;
            }
            var (ok, msg) = _usuarios.DefinirActivo(u.Id, valores[1] == "Activar");
            if (ok) Dialogos.Info(msg); else Dialogos.Aviso(msg);
        }

        private void BtnBackup_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new Microsoft.Win32.SaveFileDialog
            {
                Title = "Guardar cópia de segurança",
                FileName = $"echpro_backup_{DateTime.Now:yyyyMMdd_HHmm}.db",
                Filter = "Base de dados ECHpro (*.db)|*.db",
                DefaultExt = ".db"
            };
            if (dlg.ShowDialog() != true) return;

            try
            {
                DatabaseService.FazerBackup(dlg.FileName);
                Dialogos.Info($"Cópia guardada em:\n{dlg.FileName}");
            }
            catch (Exception ex)
            {
                Util.Log(ex, "Backup");
                Dialogos.Erro($"Não foi possível guardar a cópia:\n{ex.Message}");
            }
        }

        private void BtnPastaDados_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                {
                    FileName = DatabaseService.DataDir,
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                Util.Log(ex, "AbrirPasta");
            }
        }
    }
}
