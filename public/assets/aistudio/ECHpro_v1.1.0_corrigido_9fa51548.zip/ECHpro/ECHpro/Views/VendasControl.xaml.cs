using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using ECHpro.Helpers;
using ECHpro.Models;
using ECHpro.Services;

namespace ECHpro.Views
{
    public partial class VendasControl : UserControl
    {
        private readonly VendaService _vendaService = new();
        private readonly int _utilizadorId;

        public VendasControl(int utilizadorId, bool podeCancelar)
        {
            InitializeComponent();
            _utilizadorId = utilizadorId;
            BtnCancelarVenda.Visibility = podeCancelar ? Visibility.Visible : Visibility.Collapsed;

            Loaded += (s, e) =>
            {
                DpDe.SelectedDate = DateTime.Today;
                DpAte.SelectedDate = DateTime.Today;
                Carregar();
            };
        }

        private void Carregar()
        {
            var de = DpDe.SelectedDate ?? DateTime.Today;
            var ate = (DpAte.SelectedDate ?? DateTime.Today).AddDays(1);
            var mostrarCanceladas = ChkCanceladas.IsChecked == true;
            var lista = new List<Venda>();

            using var conn = DatabaseService.GetConnection();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
                SELECT v.Id, v.Numero, v.DataVenda, v.ClienteId, c.Nome, v.TotalBruto, v.Desconto, v.IVA,
                       v.TotalLiquido, v.ValorPago, v.Saldo, v.Status
                FROM Tbl_Venda v
                LEFT JOIN Tbl_CadCliente c ON c.Id = v.ClienteId
                WHERE v.DataVenda >= @de AND v.DataVenda < @ate
                      AND (@canc = 1 OR v.Status != 'Cancelada')
                ORDER BY v.DataVenda DESC, v.Id DESC";
            cmd.Parameters.AddWithValue("@de", Util.FormatoBD(de.Date));
            cmd.Parameters.AddWithValue("@ate", Util.FormatoBD(ate.Date));
            cmd.Parameters.AddWithValue("@canc", mostrarCanceladas ? 1 : 0);

            decimal total = 0, pago = 0, aberto = 0;
            using (var reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    var v = new Venda
                    {
                        Id = reader.GetInt32(0),
                        Numero = reader.GetString(1),
                        DataVenda = Util.ParseData(reader.GetString(2)) ?? DateTime.MinValue,
                        ClienteId = reader.IsDBNull(3) ? null : reader.GetInt32(3),
                        ClienteNome = reader.IsDBNull(4) ? "Cliente Geral" : reader.GetString(4),
                        TotalBruto = Convert.ToDecimal(reader.GetDouble(5)),
                        Desconto = Convert.ToDecimal(reader.GetDouble(6)),
                        IVA = Convert.ToDecimal(reader.GetDouble(7)),
                        TotalLiquido = Convert.ToDecimal(reader.GetDouble(8)),
                        ValorPago = Convert.ToDecimal(reader.GetDouble(9)),
                        Saldo = Convert.ToDecimal(reader.GetDouble(10)),
                        Status = reader.GetString(11)
                    };
                    lista.Add(v);
                    if (v.Status != "Cancelada")
                    {
                        total += v.TotalLiquido;
                        pago += v.ValorPago;
                        aberto += v.Saldo;
                    }
                }
            }

            GridVendas.ItemsSource = lista;
            TxtResumo.Text = $"{lista.Count(x => x.Status != "Cancelada")} venda(s)   |   " +
                             $"Total: {Util.Moeda(total)}   |   Recebido: {Util.Moeda(pago)}   |   Por receber: {Util.Moeda(aberto)}";
        }

        private void BtnFiltrar_Click(object sender, RoutedEventArgs e) => Carregar();

        private void BtnHoje_Click(object sender, RoutedEventArgs e)
        {
            DpDe.SelectedDate = DateTime.Today;
            DpAte.SelectedDate = DateTime.Today;
            Carregar();
        }

        private void GridVendas_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            // Só reage ao duplo clique numa linha (não nos cabeçalhos / barras de deslocamento)
            if (e.OriginalSource is DependencyObject origem &&
                ItemsControl.ContainerFromElement(GridVendas, origem) is DataGridRow)
            {
                BtnPdf_Click(sender, e);
            }
        }

        private void BtnPdf_Click(object sender, RoutedEventArgs e)
        {
            if (GridVendas.SelectedItem is not Venda sel)
            {
                Dialogos.Info("Seleccione primeiro uma venda na lista.");
                return;
            }

            try
            {
                var venda = _vendaService.ObterVendaCompleta(sel.Id);
                if (venda == null)
                {
                    Dialogos.Aviso("Venda não encontrada.");
                    return;
                }
                var caminho = new FacturaPdfService().GerarFactura(venda);
                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                {
                    FileName = caminho,
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                Util.Log(ex, "ReimprimirFactura");
                Dialogos.Erro($"Não foi possível gerar a factura:\n{ex.Message}");
            }
        }

        private void BtnCancelarVenda_Click(object sender, RoutedEventArgs e)
        {
            if (GridVendas.SelectedItem is not Venda sel)
            {
                Dialogos.Info("Seleccione primeiro uma venda na lista.");
                return;
            }
            if (sel.Status == "Cancelada")
            {
                Dialogos.Info("Esta venda já está cancelada.");
                return;
            }

            var valores = Dialogos.Formulario(Window.GetWindow(this),
                $"Cancelar venda {sel.Numero}", "Cancelar venda",
                new List<CampoForm>
                {
                    new() { Rotulo = "Motivo do cancelamento *" }
                },
                v => string.IsNullOrWhiteSpace(v[0]) ? "Indique o motivo do cancelamento." : null);
            if (valores == null) return;

            if (!Dialogos.Confirmar(
                $"Cancelar a venda {sel.Numero} ({Util.Moeda(sel.TotalLiquido)})?\n\n" +
                "• O stock dos produtos será reposto\n" +
                "• A dívida do cliente (se existir) será anulada\n" +
                "• O valor recebido será estornado no Livro de Caixa\n\n" +
                "Esta acção não pode ser desfeita."))
                return;

            try
            {
                _vendaService.CancelarVenda(sel.Id, _utilizadorId, valores[0].Trim());
                Dialogos.Info("Venda cancelada com sucesso.");
                Carregar();
            }
            catch (Exception ex)
            {
                Util.Log(ex, "CancelarVenda");
                Dialogos.Erro($"Não foi possível cancelar a venda:\n{ex.Message}");
            }
        }
    }
}
