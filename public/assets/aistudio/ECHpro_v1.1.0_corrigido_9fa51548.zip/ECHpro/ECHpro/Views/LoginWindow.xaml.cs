using System.Windows;
using System.Windows.Input;
using ECHpro.Helpers;
using ECHpro.Services;

namespace ECHpro.Views
{
    public partial class LoginWindow : Window
    {
        private readonly LicenseService _licenseService = new();

        public LoginWindow()
        {
            InitializeComponent();
            Loaded += LoginWindow_Loaded;
            TxtUsername.KeyDown += (s, e) => { if (e.Key == Key.Enter) TxtPassword.Focus(); };
            TxtPassword.KeyDown += (s, e) => { if (e.Key == Key.Enter) BtnLogin_Click(s, e); };
        }

        private void Header_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            // Permite arrastar a janela pelo cabeçalho (não tem barra de título)
            if (e.ButtonState == MouseButtonState.Pressed)
            {
                try { DragMove(); } catch { }
            }
        }

        private void BtnFechar_Click(object sender, RoutedEventArgs e) => Close();

        private void LoginWindow_Loaded(object sender, RoutedEventArgs e)
        {
            AtualizarInfoLicenca();

            // Verificar se precisa de activação
            if (!_licenseService.IsLicenseValid())
            {
                var result = MessageBox.Show(
                    "A sua licença de demonstração expirou ou atingiu o limite de vendas.\n\n" +
                    "Deseja activar uma licença agora?",
                    "ECHpro - Licença Expirada",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Warning);

                if (result == MessageBoxResult.Yes)
                {
                    AbrirActivacao();
                }
            }

            TxtUsername.Focus();
        }

        private void AtualizarInfoLicenca()
        {
            var info = _licenseService.GetLicenseInfo();
            TxtLicencaInfo.Foreground = new System.Windows.Media.SolidColorBrush(
                System.Windows.Media.Color.FromRgb(107, 0, 0));
            if (info.Tipo == "Demo")
            {
                TxtLicencaInfo.Text = $"Versão Demo — {info.DiasRestantes} dia(s) restante(s)\n" +
                                      "Após o período, contacte o suporte para activar.";
            }
            else if (info.IsValid)
            {
                TxtLicencaInfo.Text = $"Licença {info.Tipo} activa até {info.DataExpiracao:dd/MM/yyyy}\n" +
                                      $"({info.DiasRestantes} dias restantes)";
            }
            else
            {
                TxtLicencaInfo.Text = "⚠ Licença expirada ou inválida.\nContacte o suporte para renovar.";
                TxtLicencaInfo.Foreground = System.Windows.Media.Brushes.DarkRed;
            }
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            TxtErro.Visibility = Visibility.Collapsed;
            var username = TxtUsername.Text.Trim();
            var password = TxtPassword.Password;

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MostrarErro("Por favor, preencha o utilizador e a senha.");
                return;
            }

            // Verificar licença novamente
            if (!_licenseService.IsLicenseValid())
            {
                var result = MessageBox.Show(
                    "Licença inválida ou expirada.\nDeseja activar agora?",
                    "ECHpro - Activação Necessária",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Warning);

                if (result == MessageBoxResult.Yes)
                {
                    AbrirActivacao();
                }
                return;
            }

            try
            {
                using var conn = DatabaseService.GetConnection();
                using var cmd = conn.CreateCommand();
                cmd.CommandText = "SELECT Id, NomeCompleto, PasswordHash, NivelAcesso, Activo FROM Tbl_CadUsuario WHERE Username = @user";
                cmd.Parameters.AddWithValue("@user", username);

                using var reader = cmd.ExecuteReader();
                if (!reader.Read())
                {
                    MostrarErro("Utilizador ou senha incorrectos.");
                    return;
                }

                var activo = reader.GetInt32(4) == 1;
                if (!activo)
                {
                    MostrarErro("Este utilizador está desactivado. Contacte o administrador.");
                    return;
                }

                var hash = reader.GetString(2);
                if (!BCrypt.Net.BCrypt.Verify(password, hash))
                {
                    MostrarErro("Utilizador ou senha incorrectos.");
                    return;
                }

                var userId = reader.GetInt32(0);
                var nomeCompleto = reader.GetString(1);
                var nivel = reader.GetString(3);

                // Actualizar último login
                reader.Close();
                using var update = conn.CreateCommand();
                update.CommandText = "UPDATE Tbl_CadUsuario SET UltimoLogin = datetime('now') WHERE Id = @id";
                update.Parameters.AddWithValue("@id", userId);
                update.ExecuteNonQuery();

                // Abrir MainWindow
                var main = new MainWindow(userId, nomeCompleto, nivel);
                Application.Current.MainWindow = main;
                main.Show();
                Close();
            }
            catch (Exception ex)
            {
                Util.Log(ex, "Login");
                MostrarErro($"Erro ao autenticar: {ex.Message}");
            }
        }

        private void MostrarErro(string msg)
        {
            TxtErro.Text = msg;
            TxtErro.Visibility = Visibility.Visible;
        }

        private void AbrirActivacao()
        {
            var act = new ActivationWindow();
            act.Owner = this;
            var result = act.ShowDialog();
            AtualizarInfoLicenca();
        }
    }
}
