using System.Collections.ObjectModel;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using ECHpro.Helpers;
using ECHpro.Models;
using ECHpro.Services;

namespace ECHpro.Views
{
    public partial class PDVControl : UserControl
    {
        private readonly ProdutoService _produtoService = new();
        private readonly ClienteService _clienteService = new();
        private readonly VendaService _vendaService = new();
        private readonly ObservableCollection<VendaItem> _itens = new();
        private Cliente _clienteActual = null!;
        private int _utilizadorId;
        private string _utilizadorNome = "";
        private decimal _ivaPercentagem = 16m;

        public event EventHandler? VendaFinalizada;

        public PDVControl()
        {
            InitializeComponent();
            GridItens.ItemsSource = _itens;
            _itens.CollectionChanged += (s, e) => ActualizarTotais();
            Loaded += PDVControl_Loaded;
        }

        public void Inicializar(int utilizadorId, string utilizadorNome)
        {
            _utilizadorId = utilizadorId;
            _utilizadorNome = utilizadorNome;
        }

        private void PDVControl_Loaded(object sender, RoutedEventArgs e)
        {
            _ivaPercentagem = Util.ParseDecimal(DatabaseService.GetConfig("IVA_Percentagem", "16"), 16m);
            _clienteActual = _clienteService.ObterClienteGeral();
            TxtCliente.Text = _clienteActual.Nome;

            // Formas de pagamento
            CmbFormaPgto.Items.Clear();
            foreach (var (id, nome) in new CaixaService().ListarFormasPagamento())
                CmbFormaPgto.Items.Add(new ComboBoxItem { Content = nome, Tag = id });
            if (CmbFormaPgto.Items.Count > 0)
                CmbFormaPgto.SelectedIndex = 0;

            TxtPesquisa.Focus();
            ActualizarTotais();
        }

        #region Pesquisa de Produtos

        private void TxtPesquisa_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                PesquisarEAdicionar();
                e.Handled = true;
            }
            else if (e.Key == Key.Down && ListaResultados.Items.Count > 0)
            {
                ListaResultados.Focus();
                ListaResultados.SelectedIndex = 0;
                e.Handled = true;
            }
        }

        private void BtnPesquisar_Click(object sender, RoutedEventArgs e) => PesquisarEAdicionar();

        private void PesquisarEAdicionar()
        {
            var termo = TxtPesquisa.Text.Trim();
            if (string.IsNullOrEmpty(termo)) return;

            // Tentar match exacto por código / barras
            var exact = _produtoService.ObterPorCodigoOuBarras(termo);
            if (exact != null)
            {
                AdicionarProduto(exact);
                TxtPesquisa.Clear();
                BorderResultados.Visibility = Visibility.Collapsed;
                return;
            }

            // Pesquisa parcial
            var resultados = _produtoService.Pesquisar(termo, 20);
            ListaResultados.ItemsSource = resultados;
            BorderResultados.Visibility = resultados.Count > 0 ? Visibility.Visible : Visibility.Collapsed;

            if (resultados.Count == 1)
            {
                AdicionarProduto(resultados[0]);
                TxtPesquisa.Clear();
                BorderResultados.Visibility = Visibility.Collapsed;
            }
            else if (resultados.Count > 1)
            {
                ListaResultados.Focus();
                ListaResultados.SelectedIndex = 0;
            }
            else
            {
                MessageBox.Show("Nenhum produto encontrado.", "Pesquisa", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void ListaResultados_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (ListaResultados.SelectedItem is Produto p)
            {
                AdicionarProduto(p);
                TxtPesquisa.Clear();
                BorderResultados.Visibility = Visibility.Collapsed;
                TxtPesquisa.Focus();
            }
        }

        private void ListaResultados_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter && ListaResultados.SelectedItem is Produto p)
            {
                AdicionarProduto(p);
                TxtPesquisa.Clear();
                BorderResultados.Visibility = Visibility.Collapsed;
                TxtPesquisa.Focus();
                e.Handled = true;
            }
            else if (e.Key == Key.Escape)
            {
                BorderResultados.Visibility = Visibility.Collapsed;
                TxtPesquisa.Focus();
                e.Handled = true;
            }
        }

        #endregion

        #region Carrinho

        private void AdicionarProduto(Produto produto, decimal quantidade = 1)
        {
            var existente = _itens.FirstOrDefault(i => i.ProdutoId == produto.Id);
            var qtdTotal = (existente?.Quantidade ?? 0) + quantidade;

            // Avisa se a quantidade total no carrinho ultrapassa o stock (e não só quando é zero)
            if (qtdTotal > produto.StockActual)
            {
                var r = MessageBox.Show(
                    $"Stock insuficiente para \"{produto.Nome}\".\n" +
                    $"Disponível: {produto.StockActual:N2}  |  Na venda: {qtdTotal:N2}\n\n" +
                    "Deseja adicionar mesmo assim?",
                    "Stock insuficiente", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                if (r != MessageBoxResult.Yes) return;
            }

            if (existente != null)
            {
                existente.Quantidade += quantidade;
                existente.Recalcular();
                GridItens.Items.Refresh();
            }
            else
            {
                var item = new VendaItem
                {
                    ProdutoId = produto.Id,
                    ProdutoCodigo = produto.Codigo,
                    ProdutoNome = produto.Nome,
                    Unidade = produto.Unidade,
                    Quantidade = quantidade,
                    PrecoUnitario = produto.PrecoVenda,
                    // IVA 0% é válido (produtos isentos); só usa o padrão se vier negativo
                    IVA_Percentagem = produto.IVA_Percentagem >= 0 ? produto.IVA_Percentagem : _ivaPercentagem,
                    Desconto = 0
                };
                item.Recalcular();
                _itens.Add(item);
            }

            ActualizarTotais();
            TxtPesquisa.Focus();
        }

        private void BtnRemoverItem_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is VendaItem item)
            {
                _itens.Remove(item);
                ActualizarTotais();
            }
        }

        private void GridItens_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
        {
            if (e.EditAction == DataGridEditAction.Commit && e.Row.Item is VendaItem item)
            {
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    if (item.Quantidade <= 0) item.Quantidade = 1;
                    if (item.Desconto < 0) item.Desconto = 0;
                    // O desconto não pode ser maior que o valor da linha
                    if (item.Desconto > item.SubTotal) item.Desconto = item.SubTotal;
                    item.Recalcular();
                    GridItens.Items.Refresh();
                    ActualizarTotais();
                }), System.Windows.Threading.DispatcherPriority.Background);
            }
        }

        #endregion

        #region Totais e Pagamento

        private (decimal Subtotal, decimal Desconto, decimal Iva, decimal Total) CalcularTotais()
        {
            decimal subtotal = 0, desconto = 0, iva = 0;
            foreach (var item in _itens)
            {
                item.Recalcular();
                subtotal += item.SubTotal;
                desconto += item.Desconto;
                iva += item.ValorIVA;
            }
            return (subtotal, desconto, iva, subtotal - desconto + iva);
        }

        private bool FormaPagamentoECredito()
        {
            return CmbFormaPgto.SelectedItem is ComboBoxItem cbi &&
                   string.Equals(cbi.Content?.ToString(), "Crédito", StringComparison.OrdinalIgnoreCase);
        }

        private void ActualizarTotais()
        {
            var (subtotal, desconto, iva, total) = CalcularTotais();

            TxtSubtotal.Text = Util.Moeda(subtotal);
            TxtDesconto.Text = Util.Moeda(desconto);
            TxtIVA.Text = Util.Moeda(iva);
            TxtTotal.Text = Util.Moeda(total);
            TxtQtdItens.Text = $"{_itens.Count} item(ns)";

            var verde = new SolidColorBrush(Color.FromRgb(46, 125, 50));
            var laranja = new SolidColorBrush(Color.FromRgb(230, 81, 0));
            var vermelho = new SolidColorBrush(Color.FromRgb(107, 0, 0));

            if (Util.TryParseDecimal(TxtValorPago.Text, out var pago) && pago > 0)
            {
                var troco = pago - total;
                if (troco >= 0)
                {
                    TxtTroco.Text = $"Troco: {Util.Moeda(troco)}";
                    TxtTroco.Foreground = verde;
                }
                else
                {
                    TxtTroco.Text = $"Saldo: {Util.Moeda(-troco)}";
                    TxtTroco.Foreground = laranja;
                }
            }
            else
            {
                TxtTroco.Text = Util.Moeda(0);
                TxtTroco.Foreground = vermelho;
            }
        }

        private void TxtValor_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !Regex.IsMatch(e.Text, @"^[0-9.,]+$");
        }

        private void TxtValorPago_GotKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
        {
            TxtValorPago.SelectAll();
        }

        private void TxtValorPago_TextChanged(object sender, TextChangedEventArgs e)
        {
            // Durante o InitializeComponent os restantes controlos ainda não existem
            if (!IsLoaded) return;
            ActualizarTotais();
        }

        #endregion

        #region Cliente

        private void BtnSeleccionarCliente_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new Window
            {
                Title = "Seleccionar Cliente",
                Width = 500,
                Height = 440,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                Owner = Window.GetWindow(this),
                Background = Brushes.White
            };

            var raiz = new DockPanel { Margin = new Thickness(12) };
            var txtFiltro = new TextBox { Height = 34, Padding = new Thickness(8, 6, 8, 6), Margin = new Thickness(0, 0, 0, 8) };
            DockPanel.SetDock(txtFiltro, Dock.Top);
            var lista = new ListBox();
            raiz.Children.Add(txtFiltro);
            raiz.Children.Add(lista);

            void Carregar()
            {
                lista.Items.Clear();
                foreach (var c in _clienteService.Pesquisar(txtFiltro.Text.Trim(), 100))
                    lista.Items.Add(c);
            }

            void Escolher()
            {
                if (lista.SelectedItem is Cliente cli)
                {
                    _clienteActual = cli;
                    TxtCliente.Text = cli.Nome;
                    dlg.DialogResult = true;
                    dlg.Close();
                }
            }

            txtFiltro.TextChanged += (s, args) => Carregar();
            lista.MouseDoubleClick += (s, args) => Escolher();
            lista.KeyDown += (s, args) => { if (args.Key == Key.Enter) { Escolher(); args.Handled = true; } };
            dlg.Loaded += (s, args) => { Carregar(); txtFiltro.Focus(); };

            dlg.Content = raiz;
            dlg.ShowDialog();
        }

        #endregion

        #region Acções principais

        private void BtnFinalizar_Click(object sender, RoutedEventArgs e) => FinalizarVenda();

        private void FinalizarVenda()
        {
            if (_itens.Count == 0)
            {
                MessageBox.Show("Adicione pelo menos um produto à venda.", "Venda vazia",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var (subtotal, desconto, iva, total) = CalcularTotais();
            if (total <= 0)
            {
                MessageBox.Show("O total da venda tem de ser maior que zero.", "Venda inválida",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            Util.TryParseDecimal(TxtValorPago.Text, out var valorEntregue);
            var credito = FormaPagamentoECredito();

            // Forma "Crédito" = nada pago agora. Sem valor preenchido nas restantes = paga o total.
            decimal valorPago;
            if (credito) valorPago = 0;
            else if (valorEntregue <= 0) valorPago = total;
            else valorPago = valorEntregue;

            var troco = Math.Max(0, valorPago - total);
            var pagoEfectivo = Math.Min(valorPago, total);   // o troco não entra na caixa
            var saldo = Math.Max(0, total - pagoEfectivo);
            var status = saldo > 0 ? "Pendente" : "Paga";

            if (saldo > 0 && _clienteActual.Nome == "Cliente Geral")
            {
                var r = MessageBox.Show(
                    "Venda a crédito (ou com pagamento parcial) para \"Cliente Geral\".\n" +
                    "Recomenda-se seleccionar um cliente registado para controlar a dívida.\n\nContinuar mesmo assim?",
                    "Atenção", MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (r != MessageBoxResult.Yes) return;
            }

            int? formaPgtoId = null;
            if (CmbFormaPgto.SelectedItem is ComboBoxItem cbi && cbi.Tag is int fid)
                formaPgtoId = fid;

            Venda venda;
            try
            {
                venda = new Venda
                {
                    Serie = DatabaseService.GetConfig("SerieFactura", "FT").Trim() is { Length: > 0 } serie ? serie : "FT",
                    DataVenda = DateTime.Now,
                    ClienteId = _clienteActual.Id,
                    ClienteNome = _clienteActual.Nome,
                    UtilizadorId = _utilizadorId,
                    UtilizadorNome = _utilizadorNome,
                    TotalBruto = subtotal,
                    Desconto = desconto,
                    IVA = iva,
                    TotalLiquido = total,
                    ValorPago = pagoEfectivo,
                    Saldo = saldo,
                    Status = status,
                    TipoDocumento = "Factura",
                    Itens = _itens.ToList()
                };

                _vendaService.GuardarVenda(venda, formaPgtoId);   // atribui o Numero definitivo
            }
            catch (Exception ex)
            {
                Util.Log(ex, "GuardarVenda");
                MessageBox.Show($"Erro ao gravar a venda:\n{ex.Message}", "Erro",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            var msg = $"Venda registada com sucesso!\n\n" +
                      $"Documento: {venda.Numero}\n" +
                      $"Total: {Util.Moeda(total)}\n" +
                      $"Valor pago: {Util.Moeda(pagoEfectivo)}\n";
            if (troco > 0) msg += $"TROCO: {Util.Moeda(troco)}\n";
            if (saldo > 0) msg += $"Saldo em aberto: {Util.Moeda(saldo)}\n";
            msg += $"Estado: {status}\n\nDeseja gerar a Factura em PDF?";

            var resp = MessageBox.Show(msg, "ECHpro - Venda Concluída",
                MessageBoxButton.YesNo, MessageBoxImage.Information);

            if (resp == MessageBoxResult.Yes)
                GerarEAbrirPdf(venda);

            LimparVenda();
            VendaFinalizada?.Invoke(this, EventArgs.Empty);
        }

        private static void GerarEAbrirPdf(Venda venda)
        {
            try
            {
                var caminho = new FacturaPdfService().GerarFactura(venda);
                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                {
                    FileName = caminho,
                    UseShellExecute = true
                });
            }
            catch (Exception pdfEx)
            {
                Util.Log(pdfEx, "GerarFactura");
                MessageBox.Show($"A venda foi gravada, mas houve erro ao gerar o PDF:\n{pdfEx.Message}\n\n" +
                                "Pode gerar a factura novamente em Facturas / Vendas.",
                    "Erro PDF", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void BtnLimpar_Click(object sender, RoutedEventArgs e)
        {
            if (_itens.Count == 0) return;
            var r = MessageBox.Show("Limpar todos os itens da venda actual?", "Confirmar",
                MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (r == MessageBoxResult.Yes)
                LimparVenda();
        }

        private void BtnCancelar_Click(object sender, RoutedEventArgs e)
        {
            if (_itens.Count > 0)
            {
                var r = MessageBox.Show("Cancelar a venda actual e limpar o carrinho?", "Confirmar",
                    MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (r != MessageBoxResult.Yes) return;
            }
            LimparVenda();
        }

        private void LimparVenda()
        {
            _itens.Clear();
            _clienteActual = _clienteService.ObterClienteGeral();
            TxtCliente.Text = _clienteActual.Nome;
            TxtValorPago.Text = "0";
            TxtPesquisa.Clear();
            BorderResultados.Visibility = Visibility.Collapsed;
            if (CmbFormaPgto.Items.Count > 0)
                CmbFormaPgto.SelectedIndex = 0;
            ActualizarTotais();
            TxtPesquisa.Focus();
        }

        #endregion

        #region Atalhos de teclado (chamados pelo MainWindow)

        public void ProcessarAtalho(Key key)
        {
            switch (key)
            {
                case Key.F2:
                    TxtPesquisa.Focus();
                    TxtPesquisa.SelectAll();
                    break;
                case Key.F3:
                    BtnSeleccionarCliente_Click(this, new RoutedEventArgs());
                    break;
                case Key.F5:
                    FinalizarVenda();
                    break;
                case Key.F8:
                    BtnLimpar_Click(this, new RoutedEventArgs());
                    break;
                case Key.Delete:
                    if (GridItens.SelectedItem is VendaItem item)
                    {
                        _itens.Remove(item);
                        ActualizarTotais();
                    }
                    break;
            }
        }

        #endregion
    }
}
