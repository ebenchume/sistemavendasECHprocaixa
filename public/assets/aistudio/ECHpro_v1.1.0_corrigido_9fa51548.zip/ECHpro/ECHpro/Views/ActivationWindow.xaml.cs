using System.Windows;
using System.Windows.Media;
using ECHpro.Services;

namespace ECHpro.Views
{
    public partial class ActivationWindow : Window
    {
        private readonly LicenseService _licenseService = new();

        public ActivationWindow()
        {
            InitializeComponent();
            Loaded += ActivationWindow_Loaded;
        }

        private void ActivationWindow_Loaded(object sender, RoutedEventArgs e)
        {
            var info = _licenseService.GetLicenseInfo();
            TxtMachineId.Text = info.MachineId;

            if (info.Tipo == "Demo")
            {
                TxtEstadoActual.Text = $"Versão Demo — Expira em {info.DiasRestantes} dia(s)\n" +
                                       $"Data de expiração: {info.DataExpiracao:dd/MM/yyyy HH:mm}";
            }
            else if (info.IsValid)
            {
                TxtEstadoActual.Text = $"Licença {info.Tipo} activa\n" +
                                       $"Válida até: {info.DataExpiracao:dd/MM/yyyy} ({info.DiasRestantes} dias)";
                TxtEstadoActual.Foreground = new SolidColorBrush(Color.FromRgb(46, 125, 50));
            }
            else
            {
                TxtEstadoActual.Text = "⚠ Licença EXPIRADA ou INVÁLIDA\nÉ necessário activar uma nova chave para continuar a utilizar o sistema.";
            }
        }

        private void BtnActivar_Click(object sender, RoutedEventArgs e)
        {
            TxtMensagem.Visibility = Visibility.Collapsed;
            var chave = TxtChave.Text.Trim();

            if (string.IsNullOrWhiteSpace(chave))
            {
                MostrarMensagem("Por favor, insira a chave de activação.", false);
                return;
            }

            var (success, message) = _licenseService.ActivateKey(chave);

            if (success)
            {
                MostrarMensagem(message, true);
                MessageBox.Show(message, "ECHpro - Activação Bem-sucedida",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                DialogResult = true;
                Close();
            }
            else
            {
                MostrarMensagem(message, false);
            }
        }

        private void BtnCancelar_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private void MostrarMensagem(string msg, bool sucesso)
        {
            TxtMensagem.Text = msg;
            TxtMensagem.Foreground = sucesso
                ? new SolidColorBrush(Color.FromRgb(46, 125, 50))
                : new SolidColorBrush(Color.FromRgb(198, 40, 40));
            TxtMensagem.Visibility = Visibility.Visible;
        }
    }
}
