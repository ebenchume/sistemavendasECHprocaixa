using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using ECHpro.Helpers;
using ECHpro.Models;
using ECHpro.Services;

namespace ECHpro.Views
{
    public partial class ProdutosControl : UserControl
    {
        private const string SemCategoria = "(Sem categoria)";

        private readonly ProdutoService _service = new();
        private readonly int _utilizadorId;

        public ProdutosControl(int utilizadorId)
        {
            InitializeComponent();
            _utilizadorId = utilizadorId;
            Loaded += (s, e) => Carregar();
        }

        private void Carregar(string? termo = null)
        {
            GridProdutos.ItemsSource = string.IsNullOrWhiteSpace(termo)
                ? _service.ListarTodosActivos()
                : _service.Pesquisar(termo, 200);
        }

        private void BtnPesquisar_Click(object sender, RoutedEventArgs e) => Carregar(TxtPesquisa.Text);

        private void TxtPesquisa_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter) Carregar(TxtPesquisa.Text);
        }

        private void BtnActualizar_Click(object sender, RoutedEventArgs e) => Carregar();

        private void BtnStockBaixo_Click(object sender, RoutedEventArgs e)
        {
            GridProdutos.ItemsSource = _service.ListarStockBaixo();
        }

        private void BtnNovo_Click(object sender, RoutedEventArgs e)
        {
            var p = MostrarDialogoProduto(new Produto { Unidade = "Un", IVA_Percentagem = 16, Activo = true });
            if (p != null && Gravar(p)) Carregar();
        }

        private void GridProdutos_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (GridProdutos.SelectedItem is Produto prod)
            {
                var editado = MostrarDialogoProduto(prod);
                if (editado != null && Gravar(editado)) Carregar();
            }
        }

        private bool Gravar(Produto p)
        {
            try
            {
                _service.Guardar(p, _utilizadorId);
                return true;
            }
            catch (Exception ex) when (Util.EErroDeRestricao(ex))
            {
                Dialogos.Aviso($"Já existe um produto com o código \"{p.Codigo}\". Use um código diferente.");
                return false;
            }
            catch (Exception ex)
            {
                Util.Log(ex, "GuardarProduto");
                Dialogos.Erro($"Não foi possível guardar o produto:\n{ex.Message}");
                return false;
            }
        }

        private void BtnEntradaStock_Click(object sender, RoutedEventArgs e)
        {
            if (GridProdutos.SelectedItem is not Produto prod)
            {
                Dialogos.Info("Seleccione primeiro um produto na lista.");
                return;
            }

            var valores = Dialogos.Formulario(Window.GetWindow(this),
                $"Entrada de stock — {prod.Nome}", "Registar",
                new List<CampoForm>
                {
                    new() { Rotulo = $"Quantidade a adicionar (stock actual: {prod.StockActual:N2} {prod.Unidade})" },
                    new() { Rotulo = "Motivo / Documento", Valor = "Compra a fornecedor" }
                },
                v => Util.TryParseDecimal(v[0], out var q) && q > 0 ? null : "Indique uma quantidade maior que zero.");

            if (valores == null) return;

            try
            {
                _service.AjustarStock(prod.Id, Util.ParseDecimal(valores[0]), "Entrada",
                    string.IsNullOrWhiteSpace(valores[1]) ? "Entrada de stock" : valores[1].Trim(), _utilizadorId);
                Carregar();
            }
            catch (Exception ex)
            {
                Util.Log(ex, "EntradaStock");
                Dialogos.Erro($"Não foi possível registar a entrada:\n{ex.Message}");
            }
        }

        private void BtnDesactivar_Click(object sender, RoutedEventArgs e)
        {
            if (GridProdutos.SelectedItem is not Produto prod)
            {
                Dialogos.Info("Seleccione primeiro um produto na lista.");
                return;
            }
            if (!Dialogos.Confirmar($"Desactivar o produto \"{prod.Nome}\"?\n\nDeixa de aparecer no PDV; o histórico de vendas mantém-se."))
                return;

            try
            {
                _service.Desactivar(prod.Id);
                Carregar();
            }
            catch (Exception ex)
            {
                Util.Log(ex, "DesactivarProduto");
                Dialogos.Erro($"Não foi possível desactivar o produto:\n{ex.Message}");
            }
        }

        private Produto? MostrarDialogoProduto(Produto original)
        {
            var categorias = _service.ListarCategorias();
            var nomesCategorias = new List<string> { SemCategoria };
            nomesCategorias.AddRange(categorias.Select(c => c.Nome));
            var categoriaActual = original.CategoriaId.HasValue
                ? categorias.FirstOrDefault(c => c.Id == original.CategoriaId.Value).Nome ?? SemCategoria
                : SemCategoria;

            var campos = new List<CampoForm>
            {
                new() { Rotulo = "Código *", Valor = original.Codigo },
                new() { Rotulo = "Nome *", Valor = original.Nome },
                new() { Rotulo = "Categoria", Opcoes = nomesCategorias, Valor = categoriaActual },
                new() { Rotulo = "Unidade", Valor = original.Unidade },
                new() { Rotulo = "Preço Custo", Valor = Util.Editavel(original.PrecoCusto) },
                new() { Rotulo = "Preço Venda *", Valor = Util.Editavel(original.PrecoVenda) },
                new() { Rotulo = "Stock Actual", Valor = Util.Editavel(original.StockActual) },
                new() { Rotulo = "Stock Mínimo", Valor = Util.Editavel(original.StockMinimo) },
                new() { Rotulo = "Código de Barras", Valor = original.CodigoBarras ?? "" },
                new() { Rotulo = "IVA % (0 para isento)", Valor = Util.Editavel(original.IVA_Percentagem) }
            };

            string? Validar(string[] v)
            {
                if (string.IsNullOrWhiteSpace(v[0]) || string.IsNullOrWhiteSpace(v[1]))
                    return "Código e Nome são obrigatórios.";
                if (!Util.TryParseDecimal(v[5], out var venda) || venda < 0)
                    return "Preço de venda inválido.";
                foreach (var i in new[] { 4, 6, 7, 9 })
                {
                    if (!string.IsNullOrWhiteSpace(v[i]) && !Util.TryParseDecimal(v[i], out _))
                        return $"Valor inválido em \"{campos[i].Rotulo}\".";
                }
                var iva = Util.ParseDecimal(v[9], 16);
                if (iva < 0 || iva > 100) return "O IVA deve estar entre 0 e 100.";
                return null;
            }

            var valores = Dialogos.Formulario(Window.GetWindow(this),
                original.Id == 0 ? "Novo Produto" : "Editar Produto", "Guardar", campos, Validar);
            if (valores == null) return null;

            original.Codigo = valores[0].Trim();
            original.Nome = valores[1].Trim();
            original.CategoriaId = valores[2] == SemCategoria
                ? null
                : categorias.FirstOrDefault(c => c.Nome == valores[2]).Id;
            if (original.CategoriaId == 0) original.CategoriaId = null;
            original.Unidade = string.IsNullOrWhiteSpace(valores[3]) ? "Un" : valores[3].Trim();
            original.PrecoCusto = Util.ParseDecimal(valores[4]);
            original.PrecoVenda = Util.ParseDecimal(valores[5]);
            original.StockActual = Util.ParseDecimal(valores[6]);
            original.StockMinimo = Util.ParseDecimal(valores[7]);
            original.CodigoBarras = string.IsNullOrWhiteSpace(valores[8]) ? null : valores[8].Trim();
            original.IVA_Percentagem = Util.ParseDecimal(valores[9], 16);
            return original;
        }
    }
}
