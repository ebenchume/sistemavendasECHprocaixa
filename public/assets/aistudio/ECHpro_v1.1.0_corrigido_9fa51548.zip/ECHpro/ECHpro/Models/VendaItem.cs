namespace ECHpro.Models
{
    public class VendaItem
    {
        public int Id { get; set; }
        public int VendaId { get; set; }
        public int ProdutoId { get; set; }
        public string ProdutoCodigo { get; set; } = string.Empty;
        public string ProdutoNome { get; set; } = string.Empty;
        public string Unidade { get; set; } = "Un";
        public decimal Quantidade { get; set; } = 1;
        public decimal PrecoUnitario { get; set; }
        public decimal Desconto { get; set; } // valor absoluto (MZN) da linha
        public decimal IVA_Percentagem { get; set; } = 16;
        public decimal Total { get; set; }

        public decimal SubTotal => Quantidade * PrecoUnitario;
        public decimal ValorIVA => Math.Round((SubTotal - Desconto) * (IVA_Percentagem / 100m), 2);
        public decimal TotalComIVA => (SubTotal - Desconto) + ValorIVA;

        public void Recalcular()
        {
            Total = Math.Round((Quantidade * PrecoUnitario) - Desconto, 2);
        }
    }
}
