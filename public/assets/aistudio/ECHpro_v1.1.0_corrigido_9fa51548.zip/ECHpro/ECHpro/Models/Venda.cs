namespace ECHpro.Models
{
    public class Venda
    {
        public int Id { get; set; }
        public string Numero { get; set; } = string.Empty;
        public string Serie { get; set; } = "FT";
        public DateTime DataVenda { get; set; } = DateTime.Now;
        public int? ClienteId { get; set; }
        public string? ClienteNome { get; set; }
        public int UtilizadorId { get; set; }
        public string? UtilizadorNome { get; set; }
        public decimal TotalBruto { get; set; }
        public decimal Desconto { get; set; }
        public decimal IVA { get; set; }
        public decimal TotalLiquido { get; set; }
        public decimal ValorPago { get; set; }
        public decimal Saldo { get; set; }
        public string Status { get; set; } = "Paga"; // Paga, Pendente, Cancelada
        public string? Observacoes { get; set; }
        public string TipoDocumento { get; set; } = "Factura";

        public List<VendaItem> Itens { get; set; } = new();
    }
}
