namespace ECHpro.Models
{
    public class Cliente
    {
        public int Id { get; set; }
        public string Nome { get; set; } = string.Empty;
        public string? NUIT { get; set; }
        public string? Telefone { get; set; }
        public string? Email { get; set; }
        public string? Endereco { get; set; }
        public string? Cidade { get; set; }
        public decimal SaldoAberto { get; set; }
        public string? Observacoes { get; set; }
        public bool Activo { get; set; } = true;

        public override string ToString() => Nome;
    }
}
