namespace ECHpro.Models
{
    public class Produto
    {
        public int Id { get; set; }
        public string Codigo { get; set; } = string.Empty;
        public string Nome { get; set; } = string.Empty;
        public int? CategoriaId { get; set; }
        public string? CategoriaNome { get; set; }
        public string Unidade { get; set; } = "Un";
        public decimal PrecoCusto { get; set; }
        public decimal PrecoVenda { get; set; }
        public decimal StockActual { get; set; }
        public decimal StockMinimo { get; set; }
        public string? CodigoBarras { get; set; }
        public decimal IVA_Percentagem { get; set; } = 16;
        public bool Activo { get; set; } = true;

        public override string ToString() => $"{Codigo} - {Nome}";
    }
}
