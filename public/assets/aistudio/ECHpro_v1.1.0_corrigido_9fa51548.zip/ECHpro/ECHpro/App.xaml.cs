using System.Globalization;
using System.Threading;
using System.Windows;
using System.Windows.Markup;
using ECHpro.Helpers;
using ECHpro.Services;
using ECHpro.Views;

namespace ECHpro
{
    public partial class App : Application
    {
        // O mesmo nome é usado no instalador (AppMutex) para detectar a aplicação aberta.
        private const string NomeMutex = "ECHproSingleInstanceMutex";
        private static Mutex? _mutex;
        private bool _temMutex;

        protected override void OnStartup(StartupEventArgs e)
        {
            // Uma única instância (evita dois PDV a escrever na mesma base de dados)
            _mutex = new Mutex(true, NomeMutex, out _temMutex);
            if (!_temMutex)
            {
                MessageBox.Show("O ECHpro já está em execução.", "ECHpro",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                Shutdown();
                return;
            }

            // Erros inesperados: registar em log e mostrar mensagem em vez de fechar de repente
            DispatcherUnhandledException += (s, ev) =>
            {
                Util.Log(ev.Exception, "DispatcherUnhandledException");
                MessageBox.Show(
                    "Ocorreu um erro inesperado:\n\n" + ev.Exception.Message +
                    "\n\nO erro foi registado em %LocalAppData%\\ECHpro\\logs.\n" +
                    "Se persistir, contacte o suporte: +258 827473434",
                    "ECHpro - Erro", MessageBoxButton.OK, MessageBoxImage.Error);
                ev.Handled = true;
            };
            AppDomain.CurrentDomain.UnhandledException += (s, ev) =>
            {
                if (ev.ExceptionObject is Exception ex) Util.Log(ex, "UnhandledException");
            };
            TaskScheduler.UnobservedTaskException += (s, ev) =>
            {
                Util.Log(ev.Exception, "UnobservedTaskException");
                ev.SetObserved();
            };

            // Os bindings do WPF usam en-US por omissão; isto faz com que números e datas
            // apareçam no formato do Windows do utilizador (igual ao resto da aplicação).
            FrameworkElement.LanguageProperty.OverrideMetadata(
                typeof(FrameworkElement),
                new FrameworkPropertyMetadata(
                    XmlLanguage.GetLanguage(CultureInfo.CurrentCulture.IetfLanguageTag)));

            base.OnStartup(e);

            try
            {
                DatabaseService.InitializeDatabase();
            }
            catch (Exception ex)
            {
                Util.Log(ex, "InitializeDatabase");
                MessageBox.Show($"Erro ao inicializar a base de dados:\n{ex.Message}",
                    "ECHpro - Erro Crítico", MessageBoxButton.OK, MessageBoxImage.Error);
                Shutdown();
                return;
            }

            new LoginWindow().Show();
        }

        protected override void OnExit(ExitEventArgs e)
        {
            if (_temMutex)
            {
                // Cópia de segurança automática (uma por dia, mantém as últimas 10)
                try { DatabaseService.BackupAutomatico(); }
                catch (Exception ex) { Util.Log(ex, "BackupAutomatico"); }

                try { _mutex?.ReleaseMutex(); } catch { }
            }
            _mutex?.Dispose();
            base.OnExit(e);
        }
    }
}
