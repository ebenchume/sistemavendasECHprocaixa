using Microsoft.Data.Sqlite;
using System.IO;

namespace ECHpro.Services
{
    public static class DatabaseService
    {
        public static string DataDir { get; } = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "ECHpro");

        private static readonly string DbPath = Path.Combine(DataDir, "echpro.db");

        public static string BackupDir => Path.Combine(DataDir, "Backups");

        public static string ConnectionString => $"Data Source={DbPath}";

        public static void InitializeDatabase()
        {
            Directory.CreateDirectory(DataDir);

            using var conn = GetConnection();

            CreateTables(conn);
            CreateIndexes(conn);
            SeedInitialData(conn);
        }

        private static void CreateIndexes(SqliteConnection conn)
        {
            var indices = new[]
            {
                "CREATE INDEX IF NOT EXISTS IX_Venda_Data ON Tbl_Venda(DataVenda);",
                "CREATE INDEX IF NOT EXISTS IX_Venda_Cliente ON Tbl_Venda(ClienteId);",
                "CREATE INDEX IF NOT EXISTS IX_VendaItem_Venda ON Tbl_VendaItem(VendaId);",
                "CREATE INDEX IF NOT EXISTS IX_VendaItem_Produto ON Tbl_VendaItem(ProdutoId);",
                "CREATE INDEX IF NOT EXISTS IX_Produto_Nome ON Tbl_CadProduto(Nome);",
                "CREATE INDEX IF NOT EXISTS IX_Produto_Barras ON Tbl_CadProduto(CodigoBarras);",
                "CREATE INDEX IF NOT EXISTS IX_Caixa_Data ON Tbl_LivroCaixa(DataMovimento);"
            };
            foreach (var sql in indices)
            {
                using var cmd = conn.CreateCommand();
                cmd.CommandText = sql;
                cmd.ExecuteNonQuery();
            }
        }

        private static void CreateTables(SqliteConnection conn)
        {
            var commands = new[]
            {
                // Empresa
                @"CREATE TABLE IF NOT EXISTS Tbl_CadEmpresa (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    Nome TEXT NOT NULL,
                    NUIT TEXT,
                    Endereco TEXT,
                    Cidade TEXT,
                    Provincia TEXT,
                    Telefone TEXT,
                    Email TEXT,
                    LogoPath TEXT,
                    DataCriacao TEXT DEFAULT CURRENT_TIMESTAMP
                );",

                // Utilizadores
                @"CREATE TABLE IF NOT EXISTS Tbl_CadUsuario (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    NomeCompleto TEXT NOT NULL,
                    Username TEXT NOT NULL UNIQUE,
                    PasswordHash TEXT NOT NULL,
                    NivelAcesso TEXT NOT NULL DEFAULT 'Operador', -- Admin, Gerente, Operador
                    Activo INTEGER DEFAULT 1,
                    DataCriacao TEXT DEFAULT CURRENT_TIMESTAMP,
                    UltimoLogin TEXT
                );",

                // Clientes
                @"CREATE TABLE IF NOT EXISTS Tbl_CadCliente (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    Nome TEXT NOT NULL,
                    NUIT TEXT,
                    Telefone TEXT,
                    Email TEXT,
                    Endereco TEXT,
                    Cidade TEXT,
                    SaldoAberto REAL DEFAULT 0,
                    Observacoes TEXT,
                    Activo INTEGER DEFAULT 1,
                    DataCriacao TEXT DEFAULT CURRENT_TIMESTAMP
                );",

                // Categorias
                @"CREATE TABLE IF NOT EXISTS Tbl_CadCategoria (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    Nome TEXT NOT NULL UNIQUE,
                    Descricao TEXT,
                    Activo INTEGER DEFAULT 1
                );",

                // Produtos
                @"CREATE TABLE IF NOT EXISTS Tbl_CadProduto (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    Codigo TEXT NOT NULL UNIQUE,
                    Nome TEXT NOT NULL,
                    CategoriaId INTEGER,
                    Unidade TEXT DEFAULT 'Un',
                    PrecoCusto REAL DEFAULT 0,
                    PrecoVenda REAL NOT NULL,
                    StockActual REAL DEFAULT 0,
                    StockMinimo REAL DEFAULT 0,
                    CodigoBarras TEXT,
                    IVA_Percentagem REAL DEFAULT 16,
                    Activo INTEGER DEFAULT 1,
                    DataCriacao TEXT DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (CategoriaId) REFERENCES Tbl_CadCategoria(Id)
                );",

                // Formas de Pagamento
                @"CREATE TABLE IF NOT EXISTS Tbl_CadFormaPgto (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    Nome TEXT NOT NULL UNIQUE,
                    Activo INTEGER DEFAULT 1
                );",

                // Vendas / Facturas
                @"CREATE TABLE IF NOT EXISTS Tbl_Venda (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    Numero TEXT NOT NULL UNIQUE,
                    Serie TEXT DEFAULT 'FT',
                    DataVenda TEXT NOT NULL,
                    ClienteId INTEGER,
                    UtilizadorId INTEGER NOT NULL,
                    TotalBruto REAL DEFAULT 0,
                    Desconto REAL DEFAULT 0,
                    IVA REAL DEFAULT 0,
                    TotalLiquido REAL DEFAULT 0,
                    ValorPago REAL DEFAULT 0,
                    Saldo REAL DEFAULT 0,
                    Status TEXT DEFAULT 'Paga', -- Paga, Pendente, Cancelada
                    Observacoes TEXT,
                    TipoDocumento TEXT DEFAULT 'Factura', -- Factura, Recibo, NotaCredito
                    FOREIGN KEY (ClienteId) REFERENCES Tbl_CadCliente(Id),
                    FOREIGN KEY (UtilizadorId) REFERENCES Tbl_CadUsuario(Id)
                );",

                // Itens da Venda
                @"CREATE TABLE IF NOT EXISTS Tbl_VendaItem (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    VendaId INTEGER NOT NULL,
                    ProdutoId INTEGER NOT NULL,
                    Quantidade REAL NOT NULL,
                    PrecoUnitario REAL NOT NULL,
                    Desconto REAL DEFAULT 0,
                    IVA_Percentagem REAL DEFAULT 16,
                    Total REAL NOT NULL,
                    FOREIGN KEY (VendaId) REFERENCES Tbl_Venda(Id) ON DELETE CASCADE,
                    FOREIGN KEY (ProdutoId) REFERENCES Tbl_CadProduto(Id)
                );",

                // Pagamentos / Parcelas
                @"CREATE TABLE IF NOT EXISTS Tbl_Pagamento (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    VendaId INTEGER,
                    ClienteId INTEGER,
                    DataPagamento TEXT NOT NULL,
                    Valor REAL NOT NULL,
                    FormaPgtoId INTEGER,
                    Observacoes TEXT,
                    UtilizadorId INTEGER,
                    FOREIGN KEY (VendaId) REFERENCES Tbl_Venda(Id),
                    FOREIGN KEY (ClienteId) REFERENCES Tbl_CadCliente(Id),
                    FOREIGN KEY (FormaPgtoId) REFERENCES Tbl_CadFormaPgto(Id),
                    FOREIGN KEY (UtilizadorId) REFERENCES Tbl_CadUsuario(Id)
                );",

                // Livro de Caixa
                @"CREATE TABLE IF NOT EXISTS Tbl_LivroCaixa (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    DataMovimento TEXT NOT NULL,
                    Tipo TEXT NOT NULL, -- Entrada, Saida
                    Descricao TEXT NOT NULL,
                    Valor REAL NOT NULL,
                    FormaPgtoId INTEGER,
                    VendaId INTEGER,
                    UtilizadorId INTEGER,
                    SaldoAnterior REAL,
                    SaldoActual REAL,
                    FOREIGN KEY (FormaPgtoId) REFERENCES Tbl_CadFormaPgto(Id),
                    FOREIGN KEY (VendaId) REFERENCES Tbl_Venda(Id),
                    FOREIGN KEY (UtilizadorId) REFERENCES Tbl_CadUsuario(Id)
                );",

                // Movimentos de Stock
                @"CREATE TABLE IF NOT EXISTS Tbl_StockMovimento (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ProdutoId INTEGER NOT NULL,
                    Tipo TEXT NOT NULL, -- Entrada, Saida, Ajuste
                    Quantidade REAL NOT NULL,
                    QuantidadeAnterior REAL,
                    QuantidadeActual REAL,
                    Motivo TEXT,
                    VendaId INTEGER,
                    DataMovimento TEXT DEFAULT CURRENT_TIMESTAMP,
                    UtilizadorId INTEGER,
                    FOREIGN KEY (ProdutoId) REFERENCES Tbl_CadProduto(Id),
                    FOREIGN KEY (VendaId) REFERENCES Tbl_Venda(Id),
                    FOREIGN KEY (UtilizadorId) REFERENCES Tbl_CadUsuario(Id)
                );",

                // Configurações
                @"CREATE TABLE IF NOT EXISTS Tbl_Configuracao (
                    Chave TEXT PRIMARY KEY,
                    Valor TEXT
                );",

                // Licença
                @"CREATE TABLE IF NOT EXISTS Tbl_Licenca (
                    Id INTEGER PRIMARY KEY CHECK (Id = 1),
                    ChaveActivacao TEXT,
                    DataActivacao TEXT,
                    DataExpiracao TEXT,
                    MachineId TEXT,
                    TipoLicenca TEXT DEFAULT 'Demo', -- Demo, Anual
                    Activa INTEGER DEFAULT 0
                );",

                // Recibos
                @"CREATE TABLE IF NOT EXISTS Tbl_Recibo (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    Numero TEXT NOT NULL UNIQUE,
                    VendaId INTEGER,
                    ClienteId INTEGER,
                    DataRecibo TEXT NOT NULL,
                    Valor REAL NOT NULL,
                    FormaPgtoId INTEGER,
                    UtilizadorId INTEGER,
                    FOREIGN KEY (VendaId) REFERENCES Tbl_Venda(Id),
                    FOREIGN KEY (ClienteId) REFERENCES Tbl_CadCliente(Id),
                    FOREIGN KEY (FormaPgtoId) REFERENCES Tbl_CadFormaPgto(Id),
                    FOREIGN KEY (UtilizadorId) REFERENCES Tbl_CadUsuario(Id)
                );"
            };

            foreach (var cmdText in commands)
            {
                using var cmd = conn.CreateCommand();
                cmd.CommandText = cmdText;
                cmd.ExecuteNonQuery();
            }
        }

        private static void SeedInitialData(SqliteConnection conn)
        {
            // Verificar se já tem dados
            using (var check = conn.CreateCommand())
            {
                check.CommandText = "SELECT COUNT(*) FROM Tbl_CadUsuario";
                var count = Convert.ToInt32(check.ExecuteScalar());
                if (count > 0) return;
            }

            // Tudo ou nada: se algo falhar a meio, a base de dados não fica meio preenchida
            Exec(conn, "BEGIN");
            try
            {
                SeedDados(conn);
                Exec(conn, "COMMIT");
            }
            catch
            {
                try { Exec(conn, "ROLLBACK"); } catch { }
                throw;
            }
        }

        private static void Exec(SqliteConnection conn, string sql)
        {
            using var cmd = conn.CreateCommand();
            cmd.CommandText = sql;
            cmd.ExecuteNonQuery();
        }

        private static void SeedDados(SqliteConnection conn)
        {
            // Empresa padrão
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = @"INSERT INTO Tbl_CadEmpresa (Nome, NUIT, Endereco, Cidade, Provincia, Telefone, Email)
                    VALUES ('Minha Empresa Lda', '400000000', 'Av. Principal, 123', 'Maputo', 'Maputo', '+258 21 000000', 'info@empresa.mz')";
                cmd.ExecuteNonQuery();
            }

            // Utilizador Admin (senha: admin123)
            var hash = BCrypt.Net.BCrypt.HashPassword("admin123");
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = @"INSERT INTO Tbl_CadUsuario (NomeCompleto, Username, PasswordHash, NivelAcesso)
                    VALUES ('Administrador', 'admin', @hash, 'Admin')";
                cmd.Parameters.AddWithValue("@hash", hash);
                cmd.ExecuteNonQuery();
            }

            // Categorias padrão
            var categorias = new[] { "Agrícolas", "Alimentares", "Bebidas", "Limpeza", "Outros" };
            foreach (var cat in categorias)
            {
                using var cmd = conn.CreateCommand();
                cmd.CommandText = "INSERT INTO Tbl_CadCategoria (Nome) VALUES (@nome)";
                cmd.Parameters.AddWithValue("@nome", cat);
                cmd.ExecuteNonQuery();
            }

            // Formas de pagamento
            var formas = new[] { "Dinheiro", "M-Pesa", "Emola", "Transferência", "Cartão", "Cheque", "Crédito" };
            foreach (var f in formas)
            {
                using var cmd = conn.CreateCommand();
                cmd.CommandText = "INSERT INTO Tbl_CadFormaPgto (Nome) VALUES (@nome)";
                cmd.Parameters.AddWithValue("@nome", f);
                cmd.ExecuteNonQuery();
            }

            // Configurações padrão
            var configs = new Dictionary<string, string>
            {
                { "IVA_Percentagem", "16" },
                { "SerieFactura", "FT" },
                { "ProximoNumeroFactura", "1" },
                { "SerieRecibo", "RC" },
                { "ProximoNumeroRecibo", "1" },
                { "Moeda", "MZN" },
                { "MensagemRodape", "Obrigado pela preferência! Contacte-nos: +258 827473434" },
                { "ImpressoraTermica", "" },
                { "LarguraPapel", "80" },
                { "DemoDias", "15" },
                { "DemoVendasMax", "50" }
            };

            foreach (var kv in configs)
            {
                using var cmd = conn.CreateCommand();
                cmd.CommandText = "INSERT INTO Tbl_Configuracao (Chave, Valor) VALUES (@k, @v)";
                cmd.Parameters.AddWithValue("@k", kv.Key);
                cmd.Parameters.AddWithValue("@v", kv.Value);
                cmd.ExecuteNonQuery();
            }

            // Licença Demo inicial
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = @"INSERT INTO Tbl_Licenca (Id, TipoLicenca, DataActivacao, DataExpiracao, Activa)
                    VALUES (1, 'Demo', datetime('now','localtime'), datetime('now','localtime', '+15 days'), 1)";
                cmd.ExecuteNonQuery();
            }

            // Produtos de exemplo
            var produtos = new[]
            {
                ("P001", "Arroz 5kg", 1, "Saco", 250.00, 320.00, 50, 10),
                ("P002", "Óleo Alimentar 1L", 2, "Litro", 80.00, 110.00, 100, 20),
                ("P003", "Açúcar 1kg", 2, "Kg", 45.00, 60.00, 80, 15),
                ("P004", "Cerveja 330ml", 3, "Un", 35.00, 50.00, 200, 30),
                ("P005", "Refrigerante 2L", 3, "Un", 55.00, 75.00, 60, 10),
                ("P006", "Milho 10kg", 1, "Saco", 180.00, 240.00, 40, 8),
                ("P007", "Farinha de Trigo 1kg", 2, "Kg", 40.00, 55.00, 70, 12),
                ("P008", "Água Mineral 1.5L", 3, "Un", 20.00, 30.00, 150, 25)
            };

            foreach (var p in produtos)
            {
                using var cmd = conn.CreateCommand();
                cmd.CommandText = @"INSERT INTO Tbl_CadProduto 
                    (Codigo, Nome, CategoriaId, Unidade, PrecoCusto, PrecoVenda, StockActual, StockMinimo)
                    VALUES (@cod, @nome, @cat, @un, @custo, @venda, @stock, @min)";
                cmd.Parameters.AddWithValue("@cod", p.Item1);
                cmd.Parameters.AddWithValue("@nome", p.Item2);
                cmd.Parameters.AddWithValue("@cat", p.Item3);
                cmd.Parameters.AddWithValue("@un", p.Item4);
                cmd.Parameters.AddWithValue("@custo", p.Item5);
                cmd.Parameters.AddWithValue("@venda", p.Item6);
                cmd.Parameters.AddWithValue("@stock", p.Item7);
                cmd.Parameters.AddWithValue("@min", p.Item8);
                cmd.ExecuteNonQuery();
            }

            // Cliente genérico
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = @"INSERT INTO Tbl_CadCliente (Nome, Telefone) VALUES ('Cliente Geral', '')";
                cmd.ExecuteNonQuery();
            }
        }

        public static SqliteConnection GetConnection()
        {
            var conn = new SqliteConnection(ConnectionString);
            conn.Open();
            using var cmd = conn.CreateCommand();
            // Integridade referencial activa e espera até 10 s se a base estiver ocupada
            cmd.CommandText = "PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 10000;";
            cmd.ExecuteNonQuery();
            return conn;
        }

        /// <summary>Cria uma cópia consistente da base de dados no ficheiro indicado.</summary>
        public static string FazerBackup(string? ficheiroDestino = null)
        {
            ficheiroDestino ??= Path.Combine(BackupDir, $"echpro_{DateTime.Now:yyyyMMdd_HHmmss}.db");
            var pasta = Path.GetDirectoryName(ficheiroDestino);
            if (!string.IsNullOrEmpty(pasta)) Directory.CreateDirectory(pasta);
            if (File.Exists(ficheiroDestino)) File.Delete(ficheiroDestino);

            using var conn = GetConnection();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "VACUUM INTO @destino";
            cmd.Parameters.AddWithValue("@destino", ficheiroDestino);
            cmd.ExecuteNonQuery();
            return ficheiroDestino;
        }

        /// <summary>Uma cópia por dia em %LocalAppData%\ECHpro\Backups (mantém as 10 mais recentes).</summary>
        public static void BackupAutomatico()
        {
            if (!File.Exists(DbPath)) return;
            var hoje = Path.Combine(BackupDir, $"echpro_auto_{DateTime.Now:yyyyMMdd}.db");
            if (!File.Exists(hoje)) FazerBackup(hoje);

            var antigos = Directory.GetFiles(BackupDir, "echpro_auto_*.db")
                                   .OrderByDescending(f => f)
                                   .Skip(10);
            foreach (var f in antigos)
            {
                try { File.Delete(f); } catch { }
            }
        }

        public static string GetConfig(string chave, string defaultValue = "")
        {
            using var conn = GetConnection();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT Valor FROM Tbl_Configuracao WHERE Chave = @k";
            cmd.Parameters.AddWithValue("@k", chave);
            var result = cmd.ExecuteScalar()?.ToString();
            return result ?? defaultValue;
        }

        public static void SetConfig(string chave, string valor)
        {
            using var conn = GetConnection();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"INSERT INTO Tbl_Configuracao (Chave, Valor) VALUES (@k, @v)
                ON CONFLICT(Chave) DO UPDATE SET Valor = @v";
            cmd.Parameters.AddWithValue("@k", chave);
            cmd.Parameters.AddWithValue("@v", valor);
            cmd.ExecuteNonQuery();
        }
    }
}
