using ECHpro.Helpers;
using ECHpro.Models;
using Microsoft.Data.Sqlite;

namespace ECHpro.Services
{
    public class ProdutoService
    {
        public List<Produto> Pesquisar(string termo, int limite = 50)
        {
            var lista = new List<Produto>();
            using var conn = DatabaseService.GetConnection();
            using var cmd = conn.CreateCommand();

            if (string.IsNullOrWhiteSpace(termo))
            {
                cmd.CommandText = @"
                    SELECT p.Id, p.Codigo, p.Nome, p.CategoriaId, c.Nome as CatNome, p.Unidade,
                           p.PrecoCusto, p.PrecoVenda, p.StockActual, p.StockMinimo, p.CodigoBarras, p.IVA_Percentagem, p.Activo
                    FROM Tbl_CadProduto p
                    LEFT JOIN Tbl_CadCategoria c ON c.Id = p.CategoriaId
                    WHERE p.Activo = 1
                    ORDER BY p.Nome
                    LIMIT @lim";
                cmd.Parameters.AddWithValue("@lim", limite);
            }
            else
            {
                cmd.CommandText = @"
                    SELECT p.Id, p.Codigo, p.Nome, p.CategoriaId, c.Nome as CatNome, p.Unidade,
                           p.PrecoCusto, p.PrecoVenda, p.StockActual, p.StockMinimo, p.CodigoBarras, p.IVA_Percentagem, p.Activo
                    FROM Tbl_CadProduto p
                    LEFT JOIN Tbl_CadCategoria c ON c.Id = p.CategoriaId
                    WHERE p.Activo = 1 AND (
                        p.Nome LIKE @t OR p.Codigo LIKE @t OR p.CodigoBarras LIKE @t
                    )
                    ORDER BY 
                        CASE WHEN p.Codigo = @exact THEN 0 ELSE 1 END,
                        p.Nome
                    LIMIT @lim";
                cmd.Parameters.AddWithValue("@t", $"%{termo}%");
                cmd.Parameters.AddWithValue("@exact", termo);
                cmd.Parameters.AddWithValue("@lim", limite);
            }

            using var reader = cmd.ExecuteReader();
            while (reader.Read())
                lista.Add(MapProduto(reader));
            return lista;
        }

        public Produto? ObterPorCodigoOuBarras(string codigo)
        {
            if (string.IsNullOrWhiteSpace(codigo)) return null;
            using var conn = DatabaseService.GetConnection();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
                SELECT p.Id, p.Codigo, p.Nome, p.CategoriaId, c.Nome as CatNome, p.Unidade,
                       p.PrecoCusto, p.PrecoVenda, p.StockActual, p.StockMinimo, p.CodigoBarras, p.IVA_Percentagem, p.Activo
                FROM Tbl_CadProduto p
                LEFT JOIN Tbl_CadCategoria c ON c.Id = p.CategoriaId
                WHERE p.Activo = 1 AND (p.Codigo = @c OR p.CodigoBarras = @c)
                LIMIT 1";
            cmd.Parameters.AddWithValue("@c", codigo.Trim());
            using var reader = cmd.ExecuteReader();
            if (reader.Read()) return MapProduto(reader);
            return null;
        }

        public Produto? ObterPorId(int id)
        {
            using var conn = DatabaseService.GetConnection();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
                SELECT p.Id, p.Codigo, p.Nome, p.CategoriaId, c.Nome as CatNome, p.Unidade,
                       p.PrecoCusto, p.PrecoVenda, p.StockActual, p.StockMinimo, p.CodigoBarras, p.IVA_Percentagem, p.Activo
                FROM Tbl_CadProduto p
                LEFT JOIN Tbl_CadCategoria c ON c.Id = p.CategoriaId
                WHERE p.Id = @id";
            cmd.Parameters.AddWithValue("@id", id);
            using var reader = cmd.ExecuteReader();
            if (reader.Read()) return MapProduto(reader);
            return null;
        }

        public List<Produto> ListarTodosActivos() => Pesquisar("", 500);

        public List<Produto> ListarStockBaixo()
        {
            var lista = new List<Produto>();
            using var conn = DatabaseService.GetConnection();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
                SELECT p.Id, p.Codigo, p.Nome, p.CategoriaId, c.Nome as CatNome, p.Unidade,
                       p.PrecoCusto, p.PrecoVenda, p.StockActual, p.StockMinimo, p.CodigoBarras, p.IVA_Percentagem, p.Activo
                FROM Tbl_CadProduto p
                LEFT JOIN Tbl_CadCategoria c ON c.Id = p.CategoriaId
                WHERE p.Activo = 1 AND p.StockActual <= p.StockMinimo
                ORDER BY p.StockActual";
            using var reader = cmd.ExecuteReader();
            while (reader.Read()) lista.Add(MapProduto(reader));
            return lista;
        }

        public int Guardar(Produto p, int? utilizadorId = null)
        {
            using var conn = DatabaseService.GetConnection();
            if (p.Id == 0)
            {
                using var cmd = conn.CreateCommand();
                cmd.CommandText = @"
                    INSERT INTO Tbl_CadProduto (Codigo, Nome, CategoriaId, Unidade, PrecoCusto, PrecoVenda, StockActual, StockMinimo, CodigoBarras, IVA_Percentagem, Activo)
                    VALUES (@cod, @nome, @cat, @un, @custo, @venda, @stock, @min, @barras, @iva, 1);
                    SELECT last_insert_rowid();";
                cmd.Parameters.AddWithValue("@cod", p.Codigo);
                cmd.Parameters.AddWithValue("@nome", p.Nome);
                cmd.Parameters.AddWithValue("@cat", (object?)p.CategoriaId ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@un", p.Unidade);
                cmd.Parameters.AddWithValue("@custo", (double)p.PrecoCusto);
                cmd.Parameters.AddWithValue("@venda", (double)p.PrecoVenda);
                cmd.Parameters.AddWithValue("@stock", (double)p.StockActual);
                cmd.Parameters.AddWithValue("@min", (double)p.StockMinimo);
                cmd.Parameters.AddWithValue("@barras", (object?)p.CodigoBarras ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@iva", (double)p.IVA_Percentagem);
                return Convert.ToInt32(cmd.ExecuteScalar());
            }
            else
            {
                // Se o stock foi alterado à mão, fica registado um movimento de ajuste
                decimal stockAnterior;
                using (var cmdOld = conn.CreateCommand())
                {
                    cmdOld.CommandText = "SELECT StockActual FROM Tbl_CadProduto WHERE Id = @id";
                    cmdOld.Parameters.AddWithValue("@id", p.Id);
                    stockAnterior = Convert.ToDecimal(cmdOld.ExecuteScalar() ?? 0);
                }

                using var cmd = conn.CreateCommand();
                cmd.CommandText = @"
                    UPDATE Tbl_CadProduto SET
                        Codigo=@cod, Nome=@nome, CategoriaId=@cat, Unidade=@un,
                        PrecoCusto=@custo, PrecoVenda=@venda, StockActual=@stock, StockMinimo=@min,
                        CodigoBarras=@barras, IVA_Percentagem=@iva
                    WHERE Id=@id";
                cmd.Parameters.AddWithValue("@id", p.Id);
                cmd.Parameters.AddWithValue("@cod", p.Codigo);
                cmd.Parameters.AddWithValue("@nome", p.Nome);
                cmd.Parameters.AddWithValue("@cat", (object?)p.CategoriaId ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@un", p.Unidade);
                cmd.Parameters.AddWithValue("@custo", (double)p.PrecoCusto);
                cmd.Parameters.AddWithValue("@venda", (double)p.PrecoVenda);
                cmd.Parameters.AddWithValue("@stock", (double)p.StockActual);
                cmd.Parameters.AddWithValue("@min", (double)p.StockMinimo);
                cmd.Parameters.AddWithValue("@barras", (object?)p.CodigoBarras ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@iva", (double)p.IVA_Percentagem);
                cmd.ExecuteNonQuery();

                if (stockAnterior != p.StockActual)
                {
                    using var cmdMov = conn.CreateCommand();
                    cmdMov.CommandText = @"
                        INSERT INTO Tbl_StockMovimento (ProdutoId, Tipo, Quantidade, QuantidadeAnterior, QuantidadeActual, Motivo, DataMovimento, UtilizadorId)
                        VALUES (@pid, 'Ajuste', @qtd, @ant, @act, 'Edição manual do stock', @data, @user)";
                    cmdMov.Parameters.AddWithValue("@pid", p.Id);
                    cmdMov.Parameters.AddWithValue("@qtd", (double)Math.Abs(p.StockActual - stockAnterior));
                    cmdMov.Parameters.AddWithValue("@ant", (double)stockAnterior);
                    cmdMov.Parameters.AddWithValue("@act", (double)p.StockActual);
                    cmdMov.Parameters.AddWithValue("@data", Util.FormatoBD(DateTime.Now));
                    cmdMov.Parameters.AddWithValue("@user", (object?)utilizadorId ?? DBNull.Value);
                    cmdMov.ExecuteNonQuery();
                }
                return p.Id;
            }
        }

        public void Desactivar(int id)
        {
            using var conn = DatabaseService.GetConnection();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "UPDATE Tbl_CadProduto SET Activo = 0 WHERE Id = @id";
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
        }

        public void AjustarStock(int produtoId, decimal quantidade, string tipo, string motivo, int utilizadorId)
        {
            using var conn = DatabaseService.GetConnection();
            using var transaction = conn.BeginTransaction();
            try
            {
                using var cmdGet = conn.CreateCommand();
                cmdGet.Transaction = transaction;
                cmdGet.CommandText = "SELECT StockActual FROM Tbl_CadProduto WHERE Id = @id";
                cmdGet.Parameters.AddWithValue("@id", produtoId);
                var actual = Convert.ToDecimal(cmdGet.ExecuteScalar() ?? 0);
                var novo = tipo switch
                {
                    "Entrada" => actual + quantidade,
                    "Ajuste" => quantidade,
                    _ => actual - quantidade
                };

                using var cmdUp = conn.CreateCommand();
                cmdUp.Transaction = transaction;
                cmdUp.CommandText = "UPDATE Tbl_CadProduto SET StockActual = @s WHERE Id = @id";
                cmdUp.Parameters.AddWithValue("@s", (double)novo);
                cmdUp.Parameters.AddWithValue("@id", produtoId);
                cmdUp.ExecuteNonQuery();

                using var cmdMov = conn.CreateCommand();
                cmdMov.Transaction = transaction;
                cmdMov.CommandText = @"
                    INSERT INTO Tbl_StockMovimento (ProdutoId, Tipo, Quantidade, QuantidadeAnterior, QuantidadeActual, Motivo, DataMovimento, UtilizadorId)
                    VALUES (@pid, @tipo, @qtd, @ant, @act, @mot, @data, @user)";
                cmdMov.Parameters.AddWithValue("@data", Util.FormatoBD(DateTime.Now));
                cmdMov.Parameters.AddWithValue("@pid", produtoId);
                cmdMov.Parameters.AddWithValue("@tipo", tipo);
                cmdMov.Parameters.AddWithValue("@qtd", (double)quantidade);
                cmdMov.Parameters.AddWithValue("@ant", (double)actual);
                cmdMov.Parameters.AddWithValue("@act", (double)novo);
                cmdMov.Parameters.AddWithValue("@mot", motivo);
                cmdMov.Parameters.AddWithValue("@user", utilizadorId);
                cmdMov.ExecuteNonQuery();

                transaction.Commit();
            }
            catch { transaction.Rollback(); throw; }
        }

        public List<(int Id, string Nome)> ListarCategorias()
        {
            var lista = new List<(int, string)>();
            using var conn = DatabaseService.GetConnection();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT Id, Nome FROM Tbl_CadCategoria WHERE Activo = 1 ORDER BY Nome";
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
                lista.Add((reader.GetInt32(0), reader.GetString(1)));
            return lista;
        }

        private static Produto MapProduto(SqliteDataReader reader)
        {
            return new Produto
            {
                Id = reader.GetInt32(0),
                Codigo = reader.GetString(1),
                Nome = reader.GetString(2),
                CategoriaId = reader.IsDBNull(3) ? null : reader.GetInt32(3),
                CategoriaNome = reader.IsDBNull(4) ? null : reader.GetString(4),
                Unidade = reader.IsDBNull(5) ? "Un" : reader.GetString(5),
                PrecoCusto = reader.IsDBNull(6) ? 0 : Convert.ToDecimal(reader.GetDouble(6)),
                PrecoVenda = Convert.ToDecimal(reader.GetDouble(7)),
                StockActual = reader.IsDBNull(8) ? 0 : Convert.ToDecimal(reader.GetDouble(8)),
                StockMinimo = reader.IsDBNull(9) ? 0 : Convert.ToDecimal(reader.GetDouble(9)),
                CodigoBarras = reader.IsDBNull(10) ? null : reader.GetString(10),
                IVA_Percentagem = reader.IsDBNull(11) ? 16 : Convert.ToDecimal(reader.GetDouble(11)),
                Activo = reader.GetInt32(12) == 1
            };
        }
    }
}
