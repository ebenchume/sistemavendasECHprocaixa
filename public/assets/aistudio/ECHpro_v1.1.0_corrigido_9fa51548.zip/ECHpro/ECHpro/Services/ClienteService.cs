using ECHpro.Models;
using Microsoft.Data.Sqlite;

namespace ECHpro.Services
{
    public class ClienteService
    {
        public List<Cliente> Pesquisar(string termo, int limite = 50)
        {
            var lista = new List<Cliente>();
            using var conn = DatabaseService.GetConnection();
            using var cmd = conn.CreateCommand();

            if (string.IsNullOrWhiteSpace(termo))
            {
                cmd.CommandText = @"
                    SELECT Id, Nome, NUIT, Telefone, Email, Endereco, Cidade, SaldoAberto, Observacoes, Activo
                    FROM Tbl_CadCliente WHERE Activo = 1 ORDER BY Nome LIMIT @lim";
                cmd.Parameters.AddWithValue("@lim", limite);
            }
            else
            {
                cmd.CommandText = @"
                    SELECT Id, Nome, NUIT, Telefone, Email, Endereco, Cidade, SaldoAberto, Observacoes, Activo
                    FROM Tbl_CadCliente
                    WHERE Activo = 1 AND (Nome LIKE @t OR NUIT LIKE @t OR Telefone LIKE @t)
                    ORDER BY Nome LIMIT @lim";
                cmd.Parameters.AddWithValue("@t", $"%{termo}%");
                cmd.Parameters.AddWithValue("@lim", limite);
            }

            using var reader = cmd.ExecuteReader();
            while (reader.Read()) lista.Add(MapCliente(reader));
            return lista;
        }

        public Cliente? ObterPorId(int id)
        {
            using var conn = DatabaseService.GetConnection();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
                SELECT Id, Nome, NUIT, Telefone, Email, Endereco, Cidade, SaldoAberto, Observacoes, Activo
                FROM Tbl_CadCliente WHERE Id = @id";
            cmd.Parameters.AddWithValue("@id", id);
            using var reader = cmd.ExecuteReader();
            if (reader.Read()) return MapCliente(reader);
            return null;
        }

        public Cliente ObterClienteGeral()
        {
            using var conn = DatabaseService.GetConnection();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT Id, Nome, NUIT, Telefone, Email, Endereco, Cidade, SaldoAberto, Observacoes, Activo FROM Tbl_CadCliente WHERE Nome = 'Cliente Geral' LIMIT 1";
            using var reader = cmd.ExecuteReader();
            if (reader.Read()) return MapCliente(reader);
            reader.Close();
            using var insert = conn.CreateCommand();
            insert.CommandText = "INSERT INTO Tbl_CadCliente (Nome) VALUES ('Cliente Geral'); SELECT last_insert_rowid();";
            var id = Convert.ToInt32(insert.ExecuteScalar());
            return new Cliente { Id = id, Nome = "Cliente Geral" };
        }

        public int Guardar(Cliente c)
        {
            using var conn = DatabaseService.GetConnection();
            if (c.Id == 0)
            {
                using var cmd = conn.CreateCommand();
                cmd.CommandText = @"
                    INSERT INTO Tbl_CadCliente (Nome, NUIT, Telefone, Email, Endereco, Cidade, Observacoes, Activo)
                    VALUES (@nome, @nuit, @tel, @email, @end, @cid, @obs, 1);
                    SELECT last_insert_rowid();";
                cmd.Parameters.AddWithValue("@nome", c.Nome);
                cmd.Parameters.AddWithValue("@nuit", (object?)c.NUIT ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@tel", (object?)c.Telefone ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@email", (object?)c.Email ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@end", (object?)c.Endereco ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@cid", (object?)c.Cidade ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@obs", (object?)c.Observacoes ?? DBNull.Value);
                return Convert.ToInt32(cmd.ExecuteScalar());
            }
            else
            {
                using var cmd = conn.CreateCommand();
                cmd.CommandText = @"
                    UPDATE Tbl_CadCliente SET
                        Nome=@nome, NUIT=@nuit, Telefone=@tel, Email=@email,
                        Endereco=@end, Cidade=@cid, Observacoes=@obs
                    WHERE Id=@id";
                cmd.Parameters.AddWithValue("@id", c.Id);
                cmd.Parameters.AddWithValue("@nome", c.Nome);
                cmd.Parameters.AddWithValue("@nuit", (object?)c.NUIT ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@tel", (object?)c.Telefone ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@email", (object?)c.Email ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@end", (object?)c.Endereco ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@cid", (object?)c.Cidade ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@obs", (object?)c.Observacoes ?? DBNull.Value);
                cmd.ExecuteNonQuery();
                return c.Id;
            }
        }

        public void Desactivar(int id)
        {
            using var conn = DatabaseService.GetConnection();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "UPDATE Tbl_CadCliente SET Activo = 0 WHERE Id = @id AND Nome != 'Cliente Geral'";
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
        }

        private static Cliente MapCliente(SqliteDataReader reader)
        {
            return new Cliente
            {
                Id = reader.GetInt32(0),
                Nome = reader.GetString(1),
                NUIT = reader.IsDBNull(2) ? null : reader.GetString(2),
                Telefone = reader.IsDBNull(3) ? null : reader.GetString(3),
                Email = reader.IsDBNull(4) ? null : reader.GetString(4),
                Endereco = reader.IsDBNull(5) ? null : reader.GetString(5),
                Cidade = reader.IsDBNull(6) ? null : reader.GetString(6),
                SaldoAberto = reader.IsDBNull(7) ? 0 : Convert.ToDecimal(reader.GetDouble(7)),
                Observacoes = reader.IsDBNull(8) ? null : reader.GetString(8),
                Activo = reader.GetInt32(9) == 1
            };
        }
    }
}
