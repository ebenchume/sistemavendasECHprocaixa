using ECHpro.Helpers;
using ECHpro.Models;
using Microsoft.Data.Sqlite;

namespace ECHpro.Services
{
    public class VendaService
    {
        private const decimal Tolerancia = 0.005m;

        private static string ChaveContador(string serie) =>
            serie == "RC" ? "ProximoNumeroRecibo" : "ProximoNumeroFactura";

        /// <summary>Só para mostrar ao utilizador; o número definitivo é atribuído ao gravar.</summary>
        public string GerarProximoNumero(string serie = "FT")
        {
            var atual = DatabaseService.GetConfig(ChaveContador(serie), "1");
            if (!int.TryParse(atual, out var num)) num = 1;
            return $"{serie} {DateTime.Now.Year}/{num:D4}";
        }

        /// <summary>
        /// Grava a venda (cabeçalho, itens, stock, pagamento, saldo do cliente e livro de caixa)
        /// numa única transacção. O número do documento é atribuído dentro da transacção, na
        /// mesma ligação — antes era gravado noutra ligação e a venda ficava bloqueada.
        /// </summary>
        public int GuardarVenda(Venda venda, int? formaPgtoId = null)
        {
            if (venda.Itens.Count == 0)
                throw new InvalidOperationException("A venda não tem itens.");
            if (venda.Itens.Any(i => i.Quantidade <= 0))
                throw new InvalidOperationException("Existem itens com quantidade inválida.");

            // O valor pago nunca pode exceder o total (o excesso é troco e não entra na caixa)
            venda.ValorPago = Math.Max(0, Math.Min(venda.ValorPago, venda.TotalLiquido));
            venda.Saldo = Math.Max(0, venda.TotalLiquido - venda.ValorPago);
            if (venda.Saldo < Tolerancia) venda.Saldo = 0;
            venda.Status = venda.Saldo > 0 ? "Pendente" : "Paga";

            using var conn = DatabaseService.GetConnection();
            using var tx = conn.BeginTransaction();

            try
            {
                // ---- Número do documento (dentro da transacção) ----
                var chave = ChaveContador(venda.Serie);
                int num = 1;
                using (var cmdNum = conn.CreateCommand())
                {
                    cmdNum.Transaction = tx;
                    cmdNum.CommandText = "SELECT Valor FROM Tbl_Configuracao WHERE Chave = @k";
                    cmdNum.Parameters.AddWithValue("@k", chave);
                    var v = cmdNum.ExecuteScalar()?.ToString();
                    if (!int.TryParse(v, out num) || num < 1) num = 1;
                }

                string numero;
                while (true)
                {
                    numero = $"{venda.Serie} {venda.DataVenda.Year}/{num:D4}";
                    using var cmdEx = conn.CreateCommand();
                    cmdEx.Transaction = tx;
                    cmdEx.CommandText = "SELECT COUNT(*) FROM Tbl_Venda WHERE Numero = @n";
                    cmdEx.Parameters.AddWithValue("@n", numero);
                    if (Convert.ToInt32(cmdEx.ExecuteScalar()) == 0) break;
                    num++;
                }
                venda.Numero = numero;

                using (var cmdInc = conn.CreateCommand())
                {
                    cmdInc.Transaction = tx;
                    cmdInc.CommandText = @"INSERT INTO Tbl_Configuracao (Chave, Valor) VALUES (@k, @v)
                                           ON CONFLICT(Chave) DO UPDATE SET Valor = @v";
                    cmdInc.Parameters.AddWithValue("@k", chave);
                    cmdInc.Parameters.AddWithValue("@v", (num + 1).ToString());
                    cmdInc.ExecuteNonQuery();
                }

                // ---- Cabeçalho ----
                using (var cmd = conn.CreateCommand())
                {
                    cmd.Transaction = tx;
                    cmd.CommandText = @"
                        INSERT INTO Tbl_Venda
                        (Numero, Serie, DataVenda, ClienteId, UtilizadorId, TotalBruto, Desconto, IVA, TotalLiquido, ValorPago, Saldo, Status, Observacoes, TipoDocumento)
                        VALUES
                        (@num, @serie, @data, @cli, @user, @bruto, @desc, @iva, @liq, @pago, @saldo, @status, @obs, @tipo);
                        SELECT last_insert_rowid();";
                    cmd.Parameters.AddWithValue("@num", venda.Numero);
                    cmd.Parameters.AddWithValue("@serie", venda.Serie);
                    cmd.Parameters.AddWithValue("@data", Util.FormatoBD(venda.DataVenda));
                    cmd.Parameters.AddWithValue("@cli", (object?)venda.ClienteId ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@user", venda.UtilizadorId);
                    cmd.Parameters.AddWithValue("@bruto", (double)venda.TotalBruto);
                    cmd.Parameters.AddWithValue("@desc", (double)venda.Desconto);
                    cmd.Parameters.AddWithValue("@iva", (double)venda.IVA);
                    cmd.Parameters.AddWithValue("@liq", (double)venda.TotalLiquido);
                    cmd.Parameters.AddWithValue("@pago", (double)venda.ValorPago);
                    cmd.Parameters.AddWithValue("@saldo", (double)venda.Saldo);
                    cmd.Parameters.AddWithValue("@status", venda.Status);
                    cmd.Parameters.AddWithValue("@obs", (object?)venda.Observacoes ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@tipo", venda.TipoDocumento);
                    venda.Id = Convert.ToInt32(cmd.ExecuteScalar());
                }

                // ---- Itens + stock ----
                foreach (var item in venda.Itens)
                {
                    using (var cmdItem = conn.CreateCommand())
                    {
                        cmdItem.Transaction = tx;
                        cmdItem.CommandText = @"
                            INSERT INTO Tbl_VendaItem (VendaId, ProdutoId, Quantidade, PrecoUnitario, Desconto, IVA_Percentagem, Total)
                            VALUES (@vid, @pid, @qtd, @preco, @desc, @iva, @total)";
                        cmdItem.Parameters.AddWithValue("@vid", venda.Id);
                        cmdItem.Parameters.AddWithValue("@pid", item.ProdutoId);
                        cmdItem.Parameters.AddWithValue("@qtd", (double)item.Quantidade);
                        cmdItem.Parameters.AddWithValue("@preco", (double)item.PrecoUnitario);
                        cmdItem.Parameters.AddWithValue("@desc", (double)item.Desconto);
                        cmdItem.Parameters.AddWithValue("@iva", (double)item.IVA_Percentagem);
                        cmdItem.Parameters.AddWithValue("@total", (double)item.Total);
                        cmdItem.ExecuteNonQuery();
                    }

                    using (var cmdStock = conn.CreateCommand())
                    {
                        cmdStock.Transaction = tx;
                        cmdStock.CommandText = "UPDATE Tbl_CadProduto SET StockActual = StockActual - @qtd WHERE Id = @pid";
                        cmdStock.Parameters.AddWithValue("@qtd", (double)item.Quantidade);
                        cmdStock.Parameters.AddWithValue("@pid", item.ProdutoId);
                        cmdStock.ExecuteNonQuery();
                    }

                    decimal novoStock;
                    using (var cmdLer = conn.CreateCommand())
                    {
                        cmdLer.Transaction = tx;
                        cmdLer.CommandText = "SELECT StockActual FROM Tbl_CadProduto WHERE Id = @pid";
                        cmdLer.Parameters.AddWithValue("@pid", item.ProdutoId);
                        novoStock = Convert.ToDecimal(cmdLer.ExecuteScalar() ?? 0);
                    }

                    using var cmdMov = conn.CreateCommand();
                    cmdMov.Transaction = tx;
                    cmdMov.CommandText = @"
                        INSERT INTO Tbl_StockMovimento (ProdutoId, Tipo, Quantidade, QuantidadeAnterior, QuantidadeActual, Motivo, VendaId, DataMovimento, UtilizadorId)
                        VALUES (@pid, 'Saida', @qtd, @ant, @act, @mot, @vid, @data, @user)";
                    cmdMov.Parameters.AddWithValue("@pid", item.ProdutoId);
                    cmdMov.Parameters.AddWithValue("@qtd", (double)item.Quantidade);
                    cmdMov.Parameters.AddWithValue("@ant", (double)(novoStock + item.Quantidade));
                    cmdMov.Parameters.AddWithValue("@act", (double)novoStock);
                    cmdMov.Parameters.AddWithValue("@mot", $"Venda {venda.Numero}");
                    cmdMov.Parameters.AddWithValue("@vid", venda.Id);
                    cmdMov.Parameters.AddWithValue("@data", Util.FormatoBD(DateTime.Now));
                    cmdMov.Parameters.AddWithValue("@user", venda.UtilizadorId);
                    cmdMov.ExecuteNonQuery();
                }

                // ---- Pagamento ----
                if (venda.ValorPago > 0 && formaPgtoId.HasValue)
                {
                    using var cmdPag = conn.CreateCommand();
                    cmdPag.Transaction = tx;
                    cmdPag.CommandText = @"
                        INSERT INTO Tbl_Pagamento (VendaId, ClienteId, DataPagamento, Valor, FormaPgtoId, UtilizadorId)
                        VALUES (@vid, @cli, @data, @val, @fp, @user)";
                    cmdPag.Parameters.AddWithValue("@vid", venda.Id);
                    cmdPag.Parameters.AddWithValue("@cli", (object?)venda.ClienteId ?? DBNull.Value);
                    cmdPag.Parameters.AddWithValue("@data", Util.FormatoBD(DateTime.Now));
                    cmdPag.Parameters.AddWithValue("@val", (double)venda.ValorPago);
                    cmdPag.Parameters.AddWithValue("@fp", formaPgtoId.Value);
                    cmdPag.Parameters.AddWithValue("@user", venda.UtilizadorId);
                    cmdPag.ExecuteNonQuery();
                }

                // ---- Saldo do cliente (venda a crédito) ----
                if (venda.Saldo > 0 && venda.ClienteId.HasValue)
                {
                    using var cmdSaldo = conn.CreateCommand();
                    cmdSaldo.Transaction = tx;
                    cmdSaldo.CommandText = "UPDATE Tbl_CadCliente SET SaldoAberto = SaldoAberto + @s WHERE Id = @id";
                    cmdSaldo.Parameters.AddWithValue("@s", (double)venda.Saldo);
                    cmdSaldo.Parameters.AddWithValue("@id", venda.ClienteId.Value);
                    cmdSaldo.ExecuteNonQuery();
                }

                // ---- Livro de caixa ----
                if (venda.ValorPago > 0)
                {
                    CaixaService.InserirMovimento(conn, tx, "Entrada", $"Venda {venda.Numero}",
                        venda.ValorPago, formaPgtoId, venda.Id, venda.UtilizadorId);
                }

                tx.Commit();
                return venda.Id;
            }
            catch
            {
                tx.Rollback();
                throw;
            }
        }

        /// <summary>Cancela uma venda: repõe o stock, anula a dívida do cliente e estorna a caixa.</summary>
        public void CancelarVenda(int vendaId, int utilizadorId, string motivo)
        {
            using var conn = DatabaseService.GetConnection();
            using var tx = conn.BeginTransaction();
            try
            {
                string numero, status;
                int? clienteId;
                decimal valorPago, saldo;

                using (var cmd = conn.CreateCommand())
                {
                    cmd.Transaction = tx;
                    cmd.CommandText = "SELECT Numero, Status, ClienteId, ValorPago, Saldo FROM Tbl_Venda WHERE Id = @id";
                    cmd.Parameters.AddWithValue("@id", vendaId);
                    using var r = cmd.ExecuteReader();
                    if (!r.Read()) throw new InvalidOperationException("Venda não encontrada.");
                    numero = r.GetString(0);
                    status = r.GetString(1);
                    clienteId = r.IsDBNull(2) ? null : r.GetInt32(2);
                    valorPago = Convert.ToDecimal(r.GetDouble(3));
                    saldo = Convert.ToDecimal(r.GetDouble(4));
                }

                if (status == "Cancelada")
                    throw new InvalidOperationException("Esta venda já está cancelada.");

                // Itens
                var itens = new List<(int ProdutoId, decimal Qtd)>();
                using (var cmd = conn.CreateCommand())
                {
                    cmd.Transaction = tx;
                    cmd.CommandText = "SELECT ProdutoId, Quantidade FROM Tbl_VendaItem WHERE VendaId = @id";
                    cmd.Parameters.AddWithValue("@id", vendaId);
                    using var r = cmd.ExecuteReader();
                    while (r.Read()) itens.Add((r.GetInt32(0), Convert.ToDecimal(r.GetDouble(1))));
                }

                // Repor stock
                foreach (var (produtoId, qtd) in itens)
                {
                    decimal actual;
                    using (var cmd = conn.CreateCommand())
                    {
                        cmd.Transaction = tx;
                        cmd.CommandText = "SELECT StockActual FROM Tbl_CadProduto WHERE Id = @pid";
                        cmd.Parameters.AddWithValue("@pid", produtoId);
                        actual = Convert.ToDecimal(cmd.ExecuteScalar() ?? 0);
                    }
                    using (var cmd = conn.CreateCommand())
                    {
                        cmd.Transaction = tx;
                        cmd.CommandText = "UPDATE Tbl_CadProduto SET StockActual = StockActual + @q WHERE Id = @pid";
                        cmd.Parameters.AddWithValue("@q", (double)qtd);
                        cmd.Parameters.AddWithValue("@pid", produtoId);
                        cmd.ExecuteNonQuery();
                    }
                    using (var cmd = conn.CreateCommand())
                    {
                        cmd.Transaction = tx;
                        cmd.CommandText = @"
                            INSERT INTO Tbl_StockMovimento (ProdutoId, Tipo, Quantidade, QuantidadeAnterior, QuantidadeActual, Motivo, VendaId, DataMovimento, UtilizadorId)
                            VALUES (@pid, 'Entrada', @q, @ant, @act, @mot, @vid, @data, @user)";
                        cmd.Parameters.AddWithValue("@pid", produtoId);
                        cmd.Parameters.AddWithValue("@q", (double)qtd);
                        cmd.Parameters.AddWithValue("@ant", (double)actual);
                        cmd.Parameters.AddWithValue("@act", (double)(actual + qtd));
                        cmd.Parameters.AddWithValue("@mot", $"Cancelamento {numero}");
                        cmd.Parameters.AddWithValue("@vid", vendaId);
                        cmd.Parameters.AddWithValue("@data", Util.FormatoBD(DateTime.Now));
                        cmd.Parameters.AddWithValue("@user", utilizadorId);
                        cmd.ExecuteNonQuery();
                    }
                }

                // Dívida do cliente
                if (clienteId.HasValue && saldo > 0)
                {
                    using var cmd = conn.CreateCommand();
                    cmd.Transaction = tx;
                    cmd.CommandText = "UPDATE Tbl_CadCliente SET SaldoAberto = MAX(0, SaldoAberto - @s) WHERE Id = @id";
                    cmd.Parameters.AddWithValue("@s", (double)saldo);
                    cmd.Parameters.AddWithValue("@id", clienteId.Value);
                    cmd.ExecuteNonQuery();
                }

                // Estorno na caixa
                if (valorPago > 0)
                {
                    CaixaService.InserirMovimento(conn, tx, "Saida", $"Estorno da venda {numero} (cancelada)",
                        valorPago, null, vendaId, utilizadorId);
                }

                using (var cmd = conn.CreateCommand())
                {
                    cmd.Transaction = tx;
                    cmd.CommandText = @"
                        UPDATE Tbl_Venda SET Status = 'Cancelada', Saldo = 0,
                            Observacoes = CASE WHEN Observacoes IS NULL OR Observacoes = '' THEN @obs ELSE Observacoes || ' | ' || @obs END
                        WHERE Id = @id";
                    cmd.Parameters.AddWithValue("@obs", $"Cancelada: {motivo}");
                    cmd.Parameters.AddWithValue("@id", vendaId);
                    cmd.ExecuteNonQuery();
                }

                tx.Commit();
            }
            catch
            {
                tx.Rollback();
                throw;
            }
        }

        /// <summary>Regista um pagamento de dívida: abate as vendas pendentes mais antigas primeiro.</summary>
        public void ReceberPagamento(int clienteId, decimal valor, int formaPgtoId, int utilizadorId)
        {
            if (valor <= 0) throw new ArgumentException("O valor deve ser maior que zero.");

            using var conn = DatabaseService.GetConnection();
            using var tx = conn.BeginTransaction();
            try
            {
                decimal dividaCliente;
                string nomeCliente;
                using (var cmd = conn.CreateCommand())
                {
                    cmd.Transaction = tx;
                    cmd.CommandText = "SELECT Nome, SaldoAberto FROM Tbl_CadCliente WHERE Id = @id";
                    cmd.Parameters.AddWithValue("@id", clienteId);
                    using var r = cmd.ExecuteReader();
                    if (!r.Read()) throw new InvalidOperationException("Cliente não encontrado.");
                    nomeCliente = r.GetString(0);
                    dividaCliente = r.IsDBNull(1) ? 0 : Convert.ToDecimal(r.GetDouble(1));
                }

                if (valor > dividaCliente + Tolerancia)
                    throw new InvalidOperationException(
                        $"O valor excede a dívida do cliente ({dividaCliente:N2} MZN).");

                var pendentes = new List<(int Id, decimal Saldo, decimal Pago)>();
                using (var cmd = conn.CreateCommand())
                {
                    cmd.Transaction = tx;
                    cmd.CommandText = @"SELECT Id, Saldo, ValorPago FROM Tbl_Venda
                                        WHERE ClienteId = @c AND Status = 'Pendente' AND Saldo > 0
                                        ORDER BY DataVenda, Id";
                    cmd.Parameters.AddWithValue("@c", clienteId);
                    using var r = cmd.ExecuteReader();
                    while (r.Read())
                        pendentes.Add((r.GetInt32(0), Convert.ToDecimal(r.GetDouble(1)), Convert.ToDecimal(r.GetDouble(2))));
                }

                var restante = valor;
                foreach (var (vendaId, saldo, pago) in pendentes)
                {
                    if (restante <= 0) break;
                    var aplicar = Math.Min(restante, saldo);
                    var novoSaldo = saldo - aplicar;
                    if (novoSaldo < Tolerancia) novoSaldo = 0;

                    using (var cmd = conn.CreateCommand())
                    {
                        cmd.Transaction = tx;
                        cmd.CommandText = "UPDATE Tbl_Venda SET Saldo = @s, ValorPago = @p, Status = @st WHERE Id = @id";
                        cmd.Parameters.AddWithValue("@s", (double)novoSaldo);
                        cmd.Parameters.AddWithValue("@p", (double)(pago + aplicar));
                        cmd.Parameters.AddWithValue("@st", novoSaldo > 0 ? "Pendente" : "Paga");
                        cmd.Parameters.AddWithValue("@id", vendaId);
                        cmd.ExecuteNonQuery();
                    }
                    using (var cmd = conn.CreateCommand())
                    {
                        cmd.Transaction = tx;
                        cmd.CommandText = @"
                            INSERT INTO Tbl_Pagamento (VendaId, ClienteId, DataPagamento, Valor, FormaPgtoId, Observacoes, UtilizadorId)
                            VALUES (@vid, @cli, @data, @val, @fp, 'Pagamento de dívida', @user)";
                        cmd.Parameters.AddWithValue("@vid", vendaId);
                        cmd.Parameters.AddWithValue("@cli", clienteId);
                        cmd.Parameters.AddWithValue("@data", Util.FormatoBD(DateTime.Now));
                        cmd.Parameters.AddWithValue("@val", (double)aplicar);
                        cmd.Parameters.AddWithValue("@fp", formaPgtoId);
                        cmd.Parameters.AddWithValue("@user", utilizadorId);
                        cmd.ExecuteNonQuery();
                    }
                    restante -= aplicar;
                }

                using (var cmd = conn.CreateCommand())
                {
                    cmd.Transaction = tx;
                    cmd.CommandText = "UPDATE Tbl_CadCliente SET SaldoAberto = MAX(0, SaldoAberto - @v) WHERE Id = @id";
                    cmd.Parameters.AddWithValue("@v", (double)valor);
                    cmd.Parameters.AddWithValue("@id", clienteId);
                    cmd.ExecuteNonQuery();
                }

                CaixaService.InserirMovimento(conn, tx, "Entrada", $"Pagamento de dívida - {nomeCliente}",
                    valor, formaPgtoId, null, utilizadorId);

                tx.Commit();
            }
            catch
            {
                tx.Rollback();
                throw;
            }
        }

        /// <summary>Carrega uma venda com itens e nomes, para reimprimir a factura.</summary>
        public Venda? ObterVendaCompleta(int vendaId)
        {
            using var conn = DatabaseService.GetConnection();
            Venda? venda = null;

            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = @"
                    SELECT v.Id, v.Numero, v.Serie, v.DataVenda, v.ClienteId, c.Nome, v.UtilizadorId, u.NomeCompleto,
                           v.TotalBruto, v.Desconto, v.IVA, v.TotalLiquido, v.ValorPago, v.Saldo, v.Status, v.Observacoes, v.TipoDocumento
                    FROM Tbl_Venda v
                    LEFT JOIN Tbl_CadCliente c ON c.Id = v.ClienteId
                    LEFT JOIN Tbl_CadUsuario u ON u.Id = v.UtilizadorId
                    WHERE v.Id = @id";
                cmd.Parameters.AddWithValue("@id", vendaId);
                using var r = cmd.ExecuteReader();
                if (r.Read())
                {
                    venda = new Venda
                    {
                        Id = r.GetInt32(0),
                        Numero = r.GetString(1),
                        Serie = r.IsDBNull(2) ? "FT" : r.GetString(2),
                        DataVenda = Util.ParseData(r.GetString(3)) ?? DateTime.Now,
                        ClienteId = r.IsDBNull(4) ? null : r.GetInt32(4),
                        ClienteNome = r.IsDBNull(5) ? "Cliente Geral" : r.GetString(5),
                        UtilizadorId = r.GetInt32(6),
                        UtilizadorNome = r.IsDBNull(7) ? null : r.GetString(7),
                        TotalBruto = Convert.ToDecimal(r.GetDouble(8)),
                        Desconto = Convert.ToDecimal(r.GetDouble(9)),
                        IVA = Convert.ToDecimal(r.GetDouble(10)),
                        TotalLiquido = Convert.ToDecimal(r.GetDouble(11)),
                        ValorPago = Convert.ToDecimal(r.GetDouble(12)),
                        Saldo = Convert.ToDecimal(r.GetDouble(13)),
                        Status = r.GetString(14),
                        Observacoes = r.IsDBNull(15) ? null : r.GetString(15),
                        TipoDocumento = r.IsDBNull(16) ? "Factura" : r.GetString(16)
                    };
                }
            }
            if (venda == null) return null;

            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = @"
                    SELECT i.Id, i.ProdutoId, p.Codigo, p.Nome, p.Unidade, i.Quantidade, i.PrecoUnitario, i.Desconto, i.IVA_Percentagem, i.Total
                    FROM Tbl_VendaItem i
                    JOIN Tbl_CadProduto p ON p.Id = i.ProdutoId
                    WHERE i.VendaId = @id
                    ORDER BY i.Id";
                cmd.Parameters.AddWithValue("@id", vendaId);
                using var r = cmd.ExecuteReader();
                while (r.Read())
                {
                    venda.Itens.Add(new VendaItem
                    {
                        Id = r.GetInt32(0),
                        VendaId = vendaId,
                        ProdutoId = r.GetInt32(1),
                        ProdutoCodigo = r.GetString(2),
                        ProdutoNome = r.GetString(3),
                        Unidade = r.IsDBNull(4) ? "Un" : r.GetString(4),
                        Quantidade = Convert.ToDecimal(r.GetDouble(5)),
                        PrecoUnitario = Convert.ToDecimal(r.GetDouble(6)),
                        Desconto = Convert.ToDecimal(r.GetDouble(7)),
                        IVA_Percentagem = Convert.ToDecimal(r.GetDouble(8)),
                        Total = Convert.ToDecimal(r.GetDouble(9))
                    });
                }
            }
            return venda;
        }
    }
}
