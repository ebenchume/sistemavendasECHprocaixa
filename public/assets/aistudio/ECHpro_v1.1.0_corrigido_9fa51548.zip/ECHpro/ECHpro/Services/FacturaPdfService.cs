using ECHpro.Models;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;
using System.IO;

namespace ECHpro.Services
{
    public class FacturaPdfService
    {
        static FacturaPdfService()
        {
            QuestPDF.Settings.License = LicenseType.Community;
        }

        public string GerarFactura(Venda venda, string? pastaDestino = null)
        {
            pastaDestino ??= Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                "ECHpro", "Facturas");

            if (!Directory.Exists(pastaDestino))
                Directory.CreateDirectory(pastaDestino);

            var nomeBase = venda.Numero.Replace("/", "-").Replace(" ", "_");
            foreach (var ch in Path.GetInvalidFileNameChars()) nomeBase = nomeBase.Replace(ch, '_');
            var nomeFicheiro = $"{nomeBase}.pdf";
            var caminho = Path.Combine(pastaDestino, nomeFicheiro);

            // Dados da empresa
            string empresaNome = "Empresa", empresaNuit = "", empresaEndereco = "", empresaTel = "", empresaEmail = "";
            using (var conn = DatabaseService.GetConnection())
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = "SELECT Nome, NUIT, Endereco, Telefone, Email FROM Tbl_CadEmpresa LIMIT 1";
                using var r = cmd.ExecuteReader();
                if (r.Read())
                {
                    empresaNome = r.IsDBNull(0) ? "Empresa" : r.GetString(0);
                    empresaNuit = r.IsDBNull(1) ? "" : r.GetString(1);
                    empresaEndereco = r.IsDBNull(2) ? "" : r.GetString(2);
                    empresaTel = r.IsDBNull(3) ? "" : r.GetString(3);
                    empresaEmail = r.IsDBNull(4) ? "" : r.GetString(4);
                }
            }

            var mensagemRodape = DatabaseService.GetConfig("MensagemRodape", "Obrigado pela preferência!");

            Document.Create(container =>
            {
                container.Page(page =>
                {
                    page.Size(PageSizes.A4);
                    page.Margin(30);
                    page.DefaultTextStyle(x => x.FontSize(10).FontFamily("Arial"));

                    page.Header().Column(col =>
                    {
                        col.Item().Row(row =>
                        {
                            row.RelativeItem().Column(c =>
                            {
                                c.Item().Text(empresaNome).Bold().FontSize(16).FontColor(Colors.Red.Darken3);
                                c.Item().Text($"NUIT: {empresaNuit}");
                                c.Item().Text(empresaEndereco);
                                c.Item().Text($"Tel: {empresaTel}  |  {empresaEmail}");
                            });
                            row.ConstantItem(170).AlignRight().Column(c =>
                            {
                                c.Item().Text(venda.Status == "Cancelada" ? "FACTURA (CANCELADA)" : "FACTURA").Bold().FontSize(venda.Status == "Cancelada" ? 14 : 18).FontColor(Colors.Red.Darken3);
                                c.Item().Text(venda.Numero).Bold().FontSize(12);
                                c.Item().Text($"Data: {venda.DataVenda:dd/MM/yyyy HH:mm}");
                            });
                        });
                        col.Item().PaddingVertical(8).LineHorizontal(1).LineColor(Colors.Grey.Medium);
                    });

                    page.Content().PaddingVertical(10).Column(col =>
                    {
                        // Cliente
                        col.Item().Background(Colors.Grey.Lighten3).Padding(8).Column(c =>
                        {
                            c.Item().Text("CLIENTE").Bold().FontSize(9).FontColor(Colors.Grey.Darken1);
                            c.Item().Text(venda.ClienteNome ?? "Cliente Geral").Bold();
                        });

                        col.Item().PaddingTop(12);

                        // Tabela de itens
                        col.Item().Table(table =>
                        {
                            table.ColumnsDefinition(columns =>
                            {
                                columns.ConstantColumn(50);
                                columns.RelativeColumn(3);
                                columns.ConstantColumn(45);
                                columns.ConstantColumn(70);
                                columns.ConstantColumn(60);
                                columns.ConstantColumn(75);
                            });

                            table.Header(header =>
                            {
                                header.Cell().Background(Colors.Red.Darken3).Padding(5).Text("Cód.").FontColor(Colors.White).Bold();
                                header.Cell().Background(Colors.Red.Darken3).Padding(5).Text("Descrição").FontColor(Colors.White).Bold();
                                header.Cell().Background(Colors.Red.Darken3).Padding(5).AlignRight().Text("Qtd").FontColor(Colors.White).Bold();
                                header.Cell().Background(Colors.Red.Darken3).Padding(5).AlignRight().Text("Preço").FontColor(Colors.White).Bold();
                                header.Cell().Background(Colors.Red.Darken3).Padding(5).AlignRight().Text("Desc.").FontColor(Colors.White).Bold();
                                header.Cell().Background(Colors.Red.Darken3).Padding(5).AlignRight().Text("Total").FontColor(Colors.White).Bold();
                            });

                            foreach (var item in venda.Itens)
                            {
                                table.Cell().BorderBottom(0.5f).BorderColor(Colors.Grey.Lighten1).Padding(4).Text(item.ProdutoCodigo);
                                table.Cell().BorderBottom(0.5f).BorderColor(Colors.Grey.Lighten1).Padding(4).Text(item.ProdutoNome);
                                table.Cell().BorderBottom(0.5f).BorderColor(Colors.Grey.Lighten1).Padding(4).AlignRight().Text($"{item.Quantidade:N2}");
                                table.Cell().BorderBottom(0.5f).BorderColor(Colors.Grey.Lighten1).Padding(4).AlignRight().Text($"{item.PrecoUnitario:N2}");
                                table.Cell().BorderBottom(0.5f).BorderColor(Colors.Grey.Lighten1).Padding(4).AlignRight().Text($"{item.Desconto:N2}");
                                table.Cell().BorderBottom(0.5f).BorderColor(Colors.Grey.Lighten1).Padding(4).AlignRight().Text($"{item.Total:N2}");
                            }
                        });

                        // Totais
                        col.Item().PaddingTop(15).AlignRight().Width(220).Column(totais =>
                        {
                            totais.Item().Row(r =>
                            {
                                r.RelativeItem().Text("Subtotal:");
                                r.ConstantItem(100).AlignRight().Text($"{venda.TotalBruto:N2} MZN");
                            });
                            totais.Item().Row(r =>
                            {
                                r.RelativeItem().Text("Desconto:");
                                r.ConstantItem(100).AlignRight().Text($"{venda.Desconto:N2} MZN");
                            });
                            totais.Item().Row(r =>
                            {
                                r.RelativeItem().Text("IVA:");
                                r.ConstantItem(100).AlignRight().Text($"{venda.IVA:N2} MZN");
                            });
                            totais.Item().PaddingTop(4).Row(r =>
                            {
                                r.RelativeItem().Text("TOTAL:").Bold().FontSize(12);
                                r.ConstantItem(100).AlignRight().Text($"{venda.TotalLiquido:N2} MZN").Bold().FontSize(12).FontColor(Colors.Red.Darken3);
                            });
                            totais.Item().Row(r =>
                            {
                                r.RelativeItem().Text("Valor Pago:");
                                r.ConstantItem(100).AlignRight().Text($"{venda.ValorPago:N2} MZN");
                            });
                            if (venda.Saldo > 0)
                            {
                                totais.Item().Row(r =>
                                {
                                    r.RelativeItem().Text("Saldo em Aberto:").FontColor(Colors.Orange.Darken2);
                                    r.ConstantItem(100).AlignRight().Text($"{venda.Saldo:N2} MZN").FontColor(Colors.Orange.Darken2);
                                });
                            }
                        });
                    });

                    page.Footer().Column(col =>
                    {
                        col.Item().LineHorizontal(0.5f).LineColor(Colors.Grey.Medium);
                        col.Item().PaddingTop(5).AlignCenter().Text(mensagemRodape).FontSize(9).FontColor(Colors.Grey.Darken1);
                        col.Item().AlignCenter().Text("Suporte: +258 827473434 | ebenchume@sapo.mz").FontSize(8).FontColor(Colors.Grey.Medium);
                        col.Item().AlignCenter().Text("Documento processado por ECHpro v1.1.0").FontSize(8).FontColor(Colors.Grey.Lighten1);
                    });
                });
            }).GeneratePdf(caminho);

            return caminho;
        }
    }
}
