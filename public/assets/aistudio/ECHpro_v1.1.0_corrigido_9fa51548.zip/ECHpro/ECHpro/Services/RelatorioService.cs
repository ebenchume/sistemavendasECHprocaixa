using ECHpro.Helpers;

namespace ECHpro.Services
{
    public class ResumoVendas
    {
        public int NumeroVendas { get; set; }
        public decimal TotalVendido { get; set; }
        public decimal TotalIVA { get; set; }
        public decimal TotalRecebido { get; set; }
        public decimal TotalPorReceber { get; set; }
        public decimal LucroEstimado { get; set; }
    }

    public class ProdutoVendido
    {
        public string Codigo { get; set; } = "";
        public string Nome { get; set; } = "";
        public decimal Quantidade { get; set; }
        public decimal Total { get; set; }
    }

    public class ResumoPainel
    {
        public decimal VendasHoje { get; set; }
        public int NumeroVendasHoje { get; set; }
        public int Produtos { get; set; }
        public int StockBaixo { get; set; }
        public int Clientes { get; set; }
        public decimal DividaClientes { get; set; }
        public decimal SaldoCaixa { get; set; }
    }

    public class RelatorioService
    {
        private static object? Escalar(string sql, params (string Nome, object Valor)[] parametros)
        {
            using var conn = DatabaseService.GetConnection();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = sql;
            foreach (var (nome, valor) in parametros) cmd.Parameters.AddWithValue(nome, valor);
            var r = cmd.ExecuteScalar();
            return r == DBNull.Value ? null : r;
        }

        private static decimal Dec(object? o) => o == null ? 0 : Convert.ToDecimal(o);

        public ResumoPainel ObterResumoPainel()
        {
            var hoje = Util.FormatoBD(DateTime.Today);
            var amanha = Util.FormatoBD(DateTime.Today.AddDays(1));

            return new ResumoPainel
            {
                VendasHoje = Dec(Escalar(
                    "SELECT SUM(TotalLiquido) FROM Tbl_Venda WHERE Status <> 'Cancelada' AND DataVenda >= @a AND DataVenda < @b",
                    ("@a", hoje), ("@b", amanha))),
                NumeroVendasHoje = (int)Dec(Escalar(
                    "SELECT COUNT(*) FROM Tbl_Venda WHERE Status <> 'Cancelada' AND DataVenda >= @a AND DataVenda < @b",
                    ("@a", hoje), ("@b", amanha))),
                Produtos = (int)Dec(Escalar("SELECT COUNT(*) FROM Tbl_CadProduto WHERE Activo = 1")),
                StockBaixo = (int)Dec(Escalar("SELECT COUNT(*) FROM Tbl_CadProduto WHERE Activo = 1 AND StockActual <= StockMinimo")),
                Clientes = (int)Dec(Escalar("SELECT COUNT(*) FROM Tbl_CadCliente WHERE Activo = 1")),
                DividaClientes = Dec(Escalar("SELECT SUM(SaldoAberto) FROM Tbl_CadCliente WHERE Activo = 1")),
                SaldoCaixa = new CaixaService().SaldoActual()
            };
        }

        public ResumoVendas ObterResumo(DateTime de, DateTime ate)
        {
            var a = Util.FormatoBD(de.Date);
            var b = Util.FormatoBD(ate.Date.AddDays(1));

            var resumo = new ResumoVendas();
            using var conn = DatabaseService.GetConnection();
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = @"
                    SELECT COUNT(*), COALESCE(SUM(TotalLiquido),0), COALESCE(SUM(IVA),0),
                           COALESCE(SUM(ValorPago),0), COALESCE(SUM(Saldo),0)
                    FROM Tbl_Venda
                    WHERE Status <> 'Cancelada' AND DataVenda >= @a AND DataVenda < @b";
                cmd.Parameters.AddWithValue("@a", a);
                cmd.Parameters.AddWithValue("@b", b);
                using var r = cmd.ExecuteReader();
                if (r.Read())
                {
                    resumo.NumeroVendas = r.GetInt32(0);
                    resumo.TotalVendido = Convert.ToDecimal(r.GetDouble(1));
                    resumo.TotalIVA = Convert.ToDecimal(r.GetDouble(2));
                    resumo.TotalRecebido = Convert.ToDecimal(r.GetDouble(3));
                    resumo.TotalPorReceber = Convert.ToDecimal(r.GetDouble(4));
                }
            }

            // Lucro estimado = (total sem IVA) - (custo dos produtos vendidos)
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = @"
                    SELECT COALESCE(SUM(i.Total - i.Quantidade * p.PrecoCusto), 0)
                    FROM Tbl_VendaItem i
                    JOIN Tbl_Venda v ON v.Id = i.VendaId
                    JOIN Tbl_CadProduto p ON p.Id = i.ProdutoId
                    WHERE v.Status <> 'Cancelada' AND v.DataVenda >= @a AND v.DataVenda < @b";
                cmd.Parameters.AddWithValue("@a", a);
                cmd.Parameters.AddWithValue("@b", b);
                resumo.LucroEstimado = Convert.ToDecimal(cmd.ExecuteScalar() ?? 0);
            }
            return resumo;
        }

        public List<ProdutoVendido> ProdutosMaisVendidos(DateTime de, DateTime ate, int limite = 15)
        {
            var lista = new List<ProdutoVendido>();
            using var conn = DatabaseService.GetConnection();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
                SELECT p.Codigo, p.Nome, SUM(i.Quantidade), SUM(i.Total)
                FROM Tbl_VendaItem i
                JOIN Tbl_Venda v ON v.Id = i.VendaId
                JOIN Tbl_CadProduto p ON p.Id = i.ProdutoId
                WHERE v.Status <> 'Cancelada' AND v.DataVenda >= @a AND v.DataVenda < @b
                GROUP BY p.Id, p.Codigo, p.Nome
                ORDER BY SUM(i.Total) DESC
                LIMIT @lim";
            cmd.Parameters.AddWithValue("@a", Util.FormatoBD(de.Date));
            cmd.Parameters.AddWithValue("@b", Util.FormatoBD(ate.Date.AddDays(1)));
            cmd.Parameters.AddWithValue("@lim", limite);
            using var r = cmd.ExecuteReader();
            while (r.Read())
            {
                lista.Add(new ProdutoVendido
                {
                    Codigo = r.GetString(0),
                    Nome = r.GetString(1),
                    Quantidade = Convert.ToDecimal(r.GetDouble(2)),
                    Total = Convert.ToDecimal(r.GetDouble(3))
                });
            }
            return lista;
        }
    }
}
