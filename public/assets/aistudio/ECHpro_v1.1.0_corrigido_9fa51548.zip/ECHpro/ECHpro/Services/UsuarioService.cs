using Microsoft.Data.Sqlite;

namespace ECHpro.Services
{
    public class UsuarioService
    {
        public const int TamanhoMinimoSenha = 6;

        public (bool Sucesso, string Mensagem) AlterarSenha(int usuarioId, string senhaActual, string novaSenha)
        {
            if (string.IsNullOrEmpty(novaSenha) || novaSenha.Length < TamanhoMinimoSenha)
                return (false, $"A nova senha deve ter pelo menos {TamanhoMinimoSenha} caracteres.");

            using var conn = DatabaseService.GetConnection();
            string hash;
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = "SELECT PasswordHash FROM Tbl_CadUsuario WHERE Id = @id";
                cmd.Parameters.AddWithValue("@id", usuarioId);
                var r = cmd.ExecuteScalar()?.ToString();
                if (r == null) return (false, "Utilizador não encontrado.");
                hash = r;
            }

            if (!BCrypt.Net.BCrypt.Verify(senhaActual, hash))
                return (false, "A senha actual está incorrecta.");

            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = "UPDATE Tbl_CadUsuario SET PasswordHash = @h WHERE Id = @id";
                cmd.Parameters.AddWithValue("@h", BCrypt.Net.BCrypt.HashPassword(novaSenha));
                cmd.Parameters.AddWithValue("@id", usuarioId);
                cmd.ExecuteNonQuery();
            }
            return (true, "Senha alterada com sucesso.");
        }

        public (bool Sucesso, string Mensagem) Criar(string username, string nomeCompleto, string nivel, string senha)
        {
            username = (username ?? "").Trim();
            nomeCompleto = (nomeCompleto ?? "").Trim();

            if (username.Length < 3) return (false, "O nome de utilizador deve ter pelo menos 3 caracteres.");
            if (nomeCompleto.Length == 0) return (false, "O nome completo é obrigatório.");
            if (nivel != "Admin" && nivel != "Gerente" && nivel != "Operador") return (false, "Nível de acesso inválido.");
            if (string.IsNullOrEmpty(senha) || senha.Length < TamanhoMinimoSenha)
                return (false, $"A senha deve ter pelo menos {TamanhoMinimoSenha} caracteres.");

            try
            {
                using var conn = DatabaseService.GetConnection();
                using var cmd = conn.CreateCommand();
                cmd.CommandText = @"INSERT INTO Tbl_CadUsuario (NomeCompleto, Username, PasswordHash, NivelAcesso)
                                    VALUES (@n, @u, @h, @nivel)";
                cmd.Parameters.AddWithValue("@n", nomeCompleto);
                cmd.Parameters.AddWithValue("@u", username);
                cmd.Parameters.AddWithValue("@h", BCrypt.Net.BCrypt.HashPassword(senha));
                cmd.Parameters.AddWithValue("@nivel", nivel);
                cmd.ExecuteNonQuery();
                return (true, $"Utilizador \"{username}\" criado com sucesso.");
            }
            catch (SqliteException ex) when (ex.SqliteErrorCode == 19)
            {
                return (false, "Já existe um utilizador com esse nome.");
            }
        }

        public List<(int Id, string Username, string Nome, string Nivel, bool Activo)> Listar()
        {
            var lista = new List<(int, string, string, string, bool)>();
            using var conn = DatabaseService.GetConnection();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT Id, Username, NomeCompleto, NivelAcesso, Activo FROM Tbl_CadUsuario ORDER BY Username";
            using var r = cmd.ExecuteReader();
            while (r.Read())
                lista.Add((r.GetInt32(0), r.GetString(1), r.GetString(2), r.GetString(3), r.GetInt32(4) == 1));
            return lista;
        }

        /// <summary>Activa ou desactiva um utilizador (não permite desactivar o último Admin activo).</summary>
        public (bool Sucesso, string Mensagem) DefinirActivo(int usuarioId, bool activo)
        {
            using var conn = DatabaseService.GetConnection();
            if (!activo)
            {
                using var chk = conn.CreateCommand();
                chk.CommandText = @"SELECT COUNT(*) FROM Tbl_CadUsuario
                                    WHERE NivelAcesso = 'Admin' AND Activo = 1 AND Id <> @id";
                chk.Parameters.AddWithValue("@id", usuarioId);
                var outros = Convert.ToInt32(chk.ExecuteScalar());

                using var self = conn.CreateCommand();
                self.CommandText = "SELECT NivelAcesso FROM Tbl_CadUsuario WHERE Id = @id";
                self.Parameters.AddWithValue("@id", usuarioId);
                var nivel = self.ExecuteScalar()?.ToString();

                if (nivel == "Admin" && outros == 0)
                    return (false, "Tem de existir pelo menos um Administrador activo.");
            }

            using var cmd = conn.CreateCommand();
            cmd.CommandText = "UPDATE Tbl_CadUsuario SET Activo = @a WHERE Id = @id";
            cmd.Parameters.AddWithValue("@a", activo ? 1 : 0);
            cmd.Parameters.AddWithValue("@id", usuarioId);
            cmd.ExecuteNonQuery();
            return (true, activo ? "Utilizador activado." : "Utilizador desactivado.");
        }
    }
}
