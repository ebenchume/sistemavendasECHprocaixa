using ECHpro.Helpers;
using Microsoft.Data.Sqlite;

namespace ECHpro.Services
{
    public class MovimentoCaixa
    {
        public int Id { get; set; }
        public DateTime Data { get; set; }
        public string Tipo { get; set; } = "";
        public string Descricao { get; set; } = "";
        public decimal Valor { get; set; }
        public string FormaPgto { get; set; } = "";
        public decimal SaldoActual { get; set; }
        public decimal Entrada => Tipo == "Entrada" ? Valor : 0;
        public decimal Saida => Tipo == "Saida" ? Valor : 0;
    }

    public class CaixaService
    {
        /// <summary>
        /// Regista um movimento usando a ligação/transacção recebida, para que a gravação de uma
        /// venda e o respectivo movimento de caixa sejam atómicos.
        /// </summary>
        public static void InserirMovimento(SqliteConnection conn, SqliteTransaction? tx,
            string tipo, string descricao, decimal valor, int? formaPgtoId, int? vendaId, int? utilizadorId)
        {
            decimal saldoAnterior;
            using (var cmdSaldo = conn.CreateCommand())
            {
                cmdSaldo.Transaction = tx;
                cmdSaldo.CommandText = "SELECT SaldoActual FROM Tbl_LivroCaixa ORDER BY Id DESC LIMIT 1";
                var r = cmdSaldo.ExecuteScalar();
                saldoAnterior = (r == null || r == DBNull.Value) ? 0 : Convert.ToDecimal(r);
            }

            var saldoNovo = tipo == "Entrada" ? saldoAnterior + valor : saldoAnterior - valor;

            using var cmd = conn.CreateCommand();
            cmd.Transaction = tx;
            cmd.CommandText = @"
                INSERT INTO Tbl_LivroCaixa
                    (DataMovimento, Tipo, Descricao, Valor, FormaPgtoId, VendaId, UtilizadorId, SaldoAnterior, SaldoActual)
                VALUES (@data, @tipo, @desc, @val, @fp, @vid, @user, @ant, @act)";
            cmd.Parameters.AddWithValue("@data", Util.FormatoBD(DateTime.Now));
            cmd.Parameters.AddWithValue("@tipo", tipo);
            cmd.Parameters.AddWithValue("@desc", descricao);
            cmd.Parameters.AddWithValue("@val", (double)valor);
            cmd.Parameters.AddWithValue("@fp", (object?)formaPgtoId ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@vid", (object?)vendaId ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@user", (object?)utilizadorId ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@ant", (double)saldoAnterior);
            cmd.Parameters.AddWithValue("@act", (double)saldoNovo);
            cmd.ExecuteNonQuery();
        }

        public void RegistarManual(string tipo, string descricao, decimal valor, int? formaPgtoId, int utilizadorId)
        {
            if (tipo != "Entrada" && tipo != "Saida") throw new ArgumentException("Tipo inválido.");
            if (valor <= 0) throw new ArgumentException("O valor deve ser maior que zero.");
            if (string.IsNullOrWhiteSpace(descricao)) throw new ArgumentException("A descrição é obrigatória.");

            using var conn = DatabaseService.GetConnection();
            using var tx = conn.BeginTransaction();
            try
            {
                InserirMovimento(conn, tx, tipo, descricao.Trim(), valor, formaPgtoId, null, utilizadorId);
                tx.Commit();
            }
            catch { tx.Rollback(); throw; }
        }

        public List<MovimentoCaixa> Listar(DateTime de, DateTime ate)
        {
            var lista = new List<MovimentoCaixa>();
            using var conn = DatabaseService.GetConnection();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
                SELECT m.Id, m.DataMovimento, m.Tipo, m.Descricao, m.Valor, f.Nome, m.SaldoActual
                FROM Tbl_LivroCaixa m
                LEFT JOIN Tbl_CadFormaPgto f ON f.Id = m.FormaPgtoId
                WHERE m.DataMovimento >= @de AND m.DataMovimento < @ate
                ORDER BY m.Id DESC";
            cmd.Parameters.AddWithValue("@de", Util.FormatoBD(de.Date));
            cmd.Parameters.AddWithValue("@ate", Util.FormatoBD(ate.Date.AddDays(1)));

            using var r = cmd.ExecuteReader();
            while (r.Read())
            {
                lista.Add(new MovimentoCaixa
                {
                    Id = r.GetInt32(0),
                    Data = Util.ParseData(r.GetString(1)) ?? DateTime.MinValue,
                    Tipo = r.GetString(2),
                    Descricao = r.GetString(3),
                    Valor = Convert.ToDecimal(r.GetDouble(4)),
                    FormaPgto = r.IsDBNull(5) ? "" : r.GetString(5),
                    SaldoActual = r.IsDBNull(6) ? 0 : Convert.ToDecimal(r.GetDouble(6))
                });
            }
            return lista;
        }

        public decimal SaldoActual()
        {
            using var conn = DatabaseService.GetConnection();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT SaldoActual FROM Tbl_LivroCaixa ORDER BY Id DESC LIMIT 1";
            var r = cmd.ExecuteScalar();
            return (r == null || r == DBNull.Value) ? 0 : Convert.ToDecimal(r);
        }

        public List<(int Id, string Nome)> ListarFormasPagamento()
        {
            var lista = new List<(int, string)>();
            using var conn = DatabaseService.GetConnection();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT Id, Nome FROM Tbl_CadFormaPgto WHERE Activo = 1 ORDER BY Id";
            using var r = cmd.ExecuteReader();
            while (r.Read()) lista.Add((r.GetInt32(0), r.GetString(1)));
            return lista;
        }
    }
}
