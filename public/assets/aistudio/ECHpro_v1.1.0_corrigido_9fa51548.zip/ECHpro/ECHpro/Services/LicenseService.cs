using System.Management;
using System.Security.Cryptography;
using System.Text;
using ECHpro.Helpers;

namespace ECHpro.Services
{
    public class LicenseService
    {
        private const string SecretSalt = "ECH-PRO-2026-EBEN-CHUME-MZ-SECRET-KEY-!@#";
        private const int DemoDays = 15;
        private const int DemoMaxSales = 50;

        public class LicenseInfo
        {
            public string Tipo { get; set; } = "Demo";
            public DateTime? DataActivacao { get; set; }
            public DateTime? DataExpiracao { get; set; }
            public string? Chave { get; set; }
            public bool Activa { get; set; }
            public int DiasRestantes { get; set; }
            public string MachineId { get; set; } = "";
            public bool IsExpired => DataExpiracao.HasValue && DataExpiracao.Value < DateTime.Now;
            public bool IsValid => Activa && !IsExpired;
        }

        private static string? _machineIdCache;

        /// <summary>O ID da máquina é calculado uma vez (as consultas WMI são lentas).</summary>
        public string GetMachineId() => _machineIdCache ??= CalcularMachineId();

        private static string CalcularMachineId()
        {
            try
            {
                // Combina informações de hardware estáveis (CPU, motherboard, disco). O MAC address
                // foi removido: muda com VPN, adaptadores USB e Wi-Fi e invalidava a licença.
                var sb = new StringBuilder();

                // CPU ID
                try
                {
                    using var searcher = new ManagementObjectSearcher("SELECT ProcessorId FROM Win32_Processor");
                    foreach (var obj in searcher.Get())
                    {
                        sb.Append(obj["ProcessorId"]?.ToString()?.Trim() ?? "");
                        break;
                    }
                }
                catch { }

                // Motherboard Serial
                try
                {
                    using var searcher = new ManagementObjectSearcher("SELECT SerialNumber FROM Win32_BaseBoard");
                    foreach (var obj in searcher.Get())
                    {
                        sb.Append(obj["SerialNumber"]?.ToString()?.Trim() ?? "");
                        break;
                    }
                }
                catch { }

                // Disk Serial
                try
                {
                    using var searcher = new ManagementObjectSearcher("SELECT SerialNumber FROM Win32_DiskDrive WHERE Index=0");
                    foreach (var obj in searcher.Get())
                    {
                        sb.Append(obj["SerialNumber"]?.ToString()?.Trim() ?? "");
                        break;
                    }
                }
                catch { }

                if (sb.Length == 0)
                {
                    // Fallback para MachineName + UserName
                    sb.Append(Environment.MachineName);
                    sb.Append(Environment.UserName);
                    sb.Append(Environment.OSVersion);
                }

                using var sha = SHA256.Create();
                var hash = sha.ComputeHash(Encoding.UTF8.GetBytes(sb.ToString() + SecretSalt));
                return BitConverter.ToString(hash).Replace("-", "").Substring(0, 16).ToUpper();
            }
            catch
            {
                // Fallback absoluto
                var fallback = $"{Environment.MachineName}-{Environment.UserName}-{Environment.ProcessorCount}";
                using var sha = SHA256.Create();
                var hash = sha.ComputeHash(Encoding.UTF8.GetBytes(fallback + SecretSalt));
                return BitConverter.ToString(hash).Replace("-", "").Substring(0, 16).ToUpper();
            }
        }

        public LicenseInfo GetLicenseInfo()
        {
            var info = new LicenseInfo { MachineId = GetMachineId() };

            try
            {
                using var conn = DatabaseService.GetConnection();
                using var cmd = conn.CreateCommand();
                cmd.CommandText = "SELECT ChaveActivacao, DataActivacao, DataExpiracao, TipoLicenca, Activa, MachineId FROM Tbl_Licenca WHERE Id = 1";
                using var reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    info.Chave = reader.IsDBNull(0) ? null : reader.GetString(0);
                    info.DataActivacao = reader.IsDBNull(1) ? null : Util.ParseData(reader.GetString(1));
                    info.DataExpiracao = reader.IsDBNull(2) ? null : Util.ParseData(reader.GetString(2));
                    info.Tipo = reader.IsDBNull(3) ? "Demo" : reader.GetString(3);
                    info.Activa = !reader.IsDBNull(4) && reader.GetInt32(4) == 1;

                    var storedMachine = reader.IsDBNull(5) ? null : reader.GetString(5);
                    if (!string.IsNullOrEmpty(storedMachine) && storedMachine != info.MachineId && info.Tipo != "Demo")
                    {
                        // Machine ID não coincide - possível transferência ilegal
                        info.Activa = false;
                    }
                }

                if (info.DataExpiracao.HasValue)
                {
                    info.DiasRestantes = Math.Max(0, (int)(info.DataExpiracao.Value - DateTime.Now).TotalDays);
                }
            }
            catch
            {
                // Se tabela não existe ou erro, assume demo
                info.Tipo = "Demo";
                info.DataExpiracao = DateTime.Now.AddDays(DemoDays);
                info.DiasRestantes = DemoDays;
                info.Activa = true;
            }

            return info;
        }

        public bool IsLicenseValid()
        {
            var info = GetLicenseInfo();
            if (!info.IsValid) return false;

            // Verificar limite de vendas na demo
            if (info.Tipo == "Demo")
            {
                var salesCount = GetSalesCount();
                if (salesCount >= DemoMaxSales) return false;
            }

            return true;
        }

        private int GetSalesCount()
        {
            try
            {
                using var conn = DatabaseService.GetConnection();
                using var cmd = conn.CreateCommand();
                // Conta também as canceladas: senão bastava cancelar vendas para contornar o limite da demo
                cmd.CommandText = "SELECT COUNT(*) FROM Tbl_Venda";
                return Convert.ToInt32(cmd.ExecuteScalar());
            }
            catch { return 0; }
        }

        /// <summary>
        /// Gera uma chave de activação no formato ECH-XXXX-XXXX-XXXX-XXXX
        /// baseada no MachineId e data de expiração.
        /// </summary>
        public static string GenerateActivationKey(string machineId, DateTime expirationDate, string licenseType = "Anual")
        {
            // Payload: MachineId|Expiration|Type|Checksum
            var payload = $"{machineId.ToUpper()}|{expirationDate:yyyyMMdd}|{licenseType}";
            using var hmac = new HMACSHA256(Encoding.UTF8.GetBytes(SecretSalt));
            var hash = hmac.ComputeHash(Encoding.UTF8.GetBytes(payload));
            var hashStr = BitConverter.ToString(hash).Replace("-", "").Substring(0, 16).ToUpper();

            // Formata: ECH-XXXX-XXXX-XXXX-XXXX
            return $"ECH-{hashStr.Substring(0, 4)}-{hashStr.Substring(4, 4)}-{hashStr.Substring(8, 4)}-{hashStr.Substring(12, 4)}";
        }

        /// <summary>
        /// Valida e activa uma chave.
        /// </summary>
        public (bool Success, string Message) ActivateKey(string key)
        {
            if (string.IsNullOrWhiteSpace(key))
                return (false, "Chave de activação inválida.");

            key = key.Trim().ToUpper().Replace(" ", "");

            if (!key.StartsWith("ECH-") || key.Length != 23)
                return (false, "Formato de chave inválido. Use: ECH-XXXX-XXXX-XXXX-XXXX");

            var machineId = GetMachineId();
            var info = GetLicenseInfo();

            // Tentar validar a chave gerando possíveis hashes
            // Como a chave é derivada de HMAC, verificamos se corresponde a uma validade de 365 dias a partir de hoje ou datas próximas
            // Para simplicidade e offline: a chave é válida se o HMAC corresponder a MachineId + alguma data de expiração futura

            // Algoritmo de validação offline:
            // A chave é gerada com MachineId + DataExpiracao. O utilizador insere a chave e nós verificamos se ela
            // corresponde ao MachineId actual e a uma data de expiração válida (até 2 anos no futuro).

            bool valid = false;
            DateTime? foundExpiration = null;
            string foundType = "Anual";

            // Verificar datas de expiração possíveis (1 a 730 dias) — offline e determinístico
            for (int days = 1; days <= 730; days++)
            {
                var exp = DateTime.Now.Date.AddDays(days);
                var expectedKey = GenerateActivationKey(machineId, exp, "Anual");
                if (expectedKey == key)
                {
                    valid = true;
                    foundExpiration = exp;
                    foundType = "Anual";
                    break;
                }
            }

            if (!valid)
            {
                return (false, "Chave inválida para este computador ou já expirada.\nContacte o suporte: +258 827473434");
            }

            // Activar
            try
            {
                using var conn = DatabaseService.GetConnection();
                using var cmd = conn.CreateCommand();
                cmd.CommandText = @"UPDATE Tbl_Licenca SET 
                    ChaveActivacao = @chave,
                    DataActivacao = datetime('now','localtime'),
                    DataExpiracao = @exp,
                    MachineId = @mid,
                    TipoLicenca = @tipo,
                    Activa = 1
                    WHERE Id = 1";
                cmd.Parameters.AddWithValue("@chave", key);
                // A licença vale até ao fim do dia de expiração indicado na chave
                cmd.Parameters.AddWithValue("@exp", Util.FormatoBD(foundExpiration!.Value.AddDays(1).AddSeconds(-1)));
                cmd.Parameters.AddWithValue("@mid", machineId);
                cmd.Parameters.AddWithValue("@tipo", foundType);
                cmd.ExecuteNonQuery();

                return (true, $"Licença activada com sucesso!\nVálida até: {foundExpiration:dd/MM/yyyy}\nTipo: {foundType}");
            }
            catch (Exception ex)
            {
                return (false, $"Erro ao activar licença: {ex.Message}");
            }
        }

        public void ResetToDemo()
        {
            using var conn = DatabaseService.GetConnection();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"UPDATE Tbl_Licenca SET 
                ChaveActivacao = NULL,
                DataActivacao = datetime('now','localtime'),
                DataExpiracao = datetime('now','localtime', '+15 days'),
                MachineId = NULL,
                TipoLicenca = 'Demo',
                Activa = 1
                WHERE Id = 1";
            cmd.ExecuteNonQuery();
        }
    }
}
