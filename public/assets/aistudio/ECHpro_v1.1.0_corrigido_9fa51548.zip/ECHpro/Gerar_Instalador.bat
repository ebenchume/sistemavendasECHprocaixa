@echo off
setlocal EnableDelayedExpansion
title ECHpro - Gerador de Instalador
color 0C

set "VERSAO=1.1.0"

echo.
echo ===========================================================
echo    ECHpro v%VERSAO% - Gerador de Instalador (Setup.exe)
echo    Windows 10 / 11 (64 bits) - .NET embutido
echo ===========================================================
echo.

cd /d "%~dp0"

if not exist "ECHpro\ECHpro.csproj" (
    echo [ERRO] Execute este ficheiro a partir da pasta raiz do projecto ECHpro.
    pause
    exit /b 1
)

rem ---------- 1. .NET SDK 8 ----------
where dotnet >nul 2>&1
if errorlevel 1 (
    echo [!] .NET SDK nao encontrado. A tentar instalar com o winget...
    winget install --id Microsoft.DotNet.SDK.8 -e --accept-package-agreements --accept-source-agreements
    echo.
    echo Feche esta janela e execute o Gerar_Instalador.bat outra vez
    echo para o Windows reconhecer o .NET acabado de instalar.
    echo ^(Se o winget falhar, instale manualmente: https://dotnet.microsoft.com/download/dotnet/8.0 ^)
    pause
    exit /b 1
)

dotnet --list-sdks | findstr /b "8." >nul
if errorlevel 1 (
    echo [ERRO] E necessario o .NET SDK 8.x. Versoes instaladas:
    dotnet --list-sdks
    echo Instale em: https://dotnet.microsoft.com/download/dotnet/8.0
    pause
    exit /b 1
)

rem ---------- 2. Inno Setup 6 ----------
set "ISCC="
for %%P in (
    "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
    "%ProgramFiles%\Inno Setup 6\ISCC.exe"
    "%LocalAppData%\Programs\Inno Setup 6\ISCC.exe"
) do (
    if exist %%P set "ISCC=%%~P"
)

if not defined ISCC (
    echo [!] Inno Setup 6 nao encontrado. A tentar instalar com o winget...
    winget install --id JRSoftware.InnoSetup -e --accept-package-agreements --accept-source-agreements
    for %%P in (
        "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
        "%ProgramFiles%\Inno Setup 6\ISCC.exe"
        "%LocalAppData%\Programs\Inno Setup 6\ISCC.exe"
    ) do (
        if exist %%P set "ISCC=%%~P"
    )
)

if not defined ISCC (
    echo [ERRO] Nao foi possivel encontrar o Inno Setup 6.
    echo        Instale em https://jrsoftware.org/isdl.php e execute de novo.
    pause
    exit /b 1
)

rem ---------- 3. Publicar a aplicacao ----------
echo.
echo [1/2] A publicar a aplicacao (pode demorar 1-3 minutos)...
if exist "publish" rmdir /s /q "publish"

dotnet publish "ECHpro\ECHpro.csproj" -c Release -r win-x64 --self-contained true -o "publish" -p:DebugType=none -p:DebugSymbols=false
if errorlevel 1 (
    echo.
    echo [ERRO] Falha na publicacao. Veja as mensagens acima.
    pause
    exit /b 1
)

if not exist "publish\ECHpro.exe" (
    echo [ERRO] publish\ECHpro.exe nao foi gerado.
    pause
    exit /b 1
)

rem ---------- 4. Compilar o instalador ----------
echo.
echo [2/2] A criar o instalador...
if exist "Installer\Output" rmdir /s /q "Installer\Output"

"%ISCC%" "/DMyAppVersion=%VERSAO%" "Installer\ECHpro.iss"
if errorlevel 1 (
    echo.
    echo [ERRO] Falha ao compilar o instalador.
    pause
    exit /b 1
)

echo.
echo ===========================================================
echo    CONCLUIDO!
echo    Instalador: %CD%\Installer\Output\ECHpro_Setup_v%VERSAO%.exe
echo ===========================================================
echo.
explorer "%CD%\Installer\Output"
pause
exit /b 0
