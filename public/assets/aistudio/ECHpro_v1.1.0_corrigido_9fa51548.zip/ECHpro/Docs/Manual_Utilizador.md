# Manual de Utilizador — ECHpro v1.0.0

**Sistema de Gestão de Vendas e Faturação**  
Desenvolvido por Eben Chume  
Suporte: +258 827473434 | ebenchume@sapo.mz

---

## 1. Instalação

1. Execute o ficheiro `ECHpro_Setup_v1.0.0.exe`
2. Siga o assistente de instalação
3. Certifique-se de que o **.NET 8 Desktop Runtime** está instalado  
   (download em: https://dotnet.microsoft.com/download/dotnet/8.0)
4. Inicie o ECHpro a partir do menu Iniciar ou atalho no Ambiente de Trabalho

## 2. Primeiro Acesso

- **Utilizador:** `admin`  
- **Senha:** `admin123`  

**Importante:** Altere a senha do administrador após o primeiro login (funcionalidade em evolução; por agora contacte o suporte).

A versão Demo permite **15 dias** de utilização completa ou **50 vendas**.

## 3. Activação da Licença

1. No menu lateral clique em **Activação / Licença**
2. Anote o **ID da Máquina** apresentado
3. Contacte o suporte (+258 827473434 ou ebenchume@sapo.mz) e envie o ID
4. Receberá uma chave no formato `ECH-XXXX-XXXX-XXXX-XXXX`
5. Introduza a chave e clique em **ACTIVAR**

## 4. Ponto de Venda (PDV)

1. Menu → **Ponto de Venda (PDV)**
2. Digite o código, nome ou código de barras do produto e pressione **Enter**
3. Ajuste quantidades e descontos na grelha
4. Seleccione o cliente (botão **...** ou tecla **F3**)
5. Escolha a forma de pagamento e indique o valor pago
6. Pressione **F5** ou o botão **FINALIZAR VENDA**
7. Opcionalmente gere a Factura em PDF

### Atalhos de teclado no PDV
| Tecla | Acção              |
|-------|--------------------|
| F2    | Focar pesquisa     |
| F3    | Seleccionar cliente|
| F5    | Finalizar venda    |
| F8    | Limpar carrinho    |
| Del   | Remover item       |

## 5. Produtos e Stock

- Menu → **Produtos / Stock**
- Pesquise por nome ou código
- Clique em **+ Novo Produto** para registar
- Faça duplo clique num produto para editar
- Use o filtro **Stock Baixo** para ver produtos abaixo do mínimo

## 6. Clientes

- Menu → **Clientes**
- Clique em **+ Novo Cliente** para registar
- Faça duplo clique num cliente para editar

## 7. Facturas / Histórico de Vendas

- Menu → **Facturas / Vendas**
- Filtre por período de datas
- Consulte totais, valores pagos e saldos

## 8. Configurações

- Apenas **Admin** e **Gerente**
- Dados da empresa (NUIT, endereço, contactos)
- Taxa de IVA, série de documentos e mensagem de rodapé

## 9. Contactos de Suporte

- **WhatsApp / Telefone:** +258 827473434  
- **Email:** ebenchume@sapo.mz  

Estes contactos aparecem no rodapé de todos os ecrãs principais e no ecrã de activação.

---

© 2026 Eben Chume. Todos os direitos reservados.
