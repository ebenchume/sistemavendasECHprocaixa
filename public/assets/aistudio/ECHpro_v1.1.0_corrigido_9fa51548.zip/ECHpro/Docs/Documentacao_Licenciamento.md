# Documentação Técnica — Sistema de Licenciamento ECHpro

## Visão Geral

O ECHpro implementa um sistema de licenciamento **offline** robusto, sem necessidade de servidor ou ligação à internet para activação ou verificação.

### Componentes

1. **LicenseService** (`Services/LicenseService.cs`)
2. **Tabela Tbl_Licenca** na base SQLite
3. **ECHpro.KeyGen** — ferramenta de geração de chaves para o desenvolvedor/suporte
4. **Ecrã de Activação** (`Views/ActivationWindow`)

## Machine Fingerprint (Machine ID)

O identificador único da máquina é gerado a partir de:

- ProcessorId (Win32_Processor)
- SerialNumber da motherboard (Win32_BaseBoard)
- SerialNumber do disco principal (Win32_DiskDrive)
- MAC Address da placa de rede activa
- Fallback: MachineName + UserName + OSVersion

O resultado é um hash SHA-256 truncado para 16 caracteres hexadecimais maiúsculos.

## Formato da Chave

```
ECH-XXXX-XXXX-XXXX-XXXX
```

Onde os 16 caracteres `X` são os primeiros 16 hex do HMAC-SHA256 do payload:

```
payload = "{MachineId}|{yyyyMMdd}|{TipoLicenca}"
HMAC-SHA256(payload, SecretSalt)
```

- **SecretSalt**: constante privada no código (`ECH-PRO-2026-EBEN-CHUME-MZ-SECRET-KEY-!@#`)
- **TipoLicenca**: normalmente `"Anual"`

## Fluxo de Activação

1. Cliente abre o ecrã de Activação → vê o Machine ID
2. Envia o Machine ID ao suporte (+258 827473434 / ebenchume@sapo.mz)
3. Suporte executa o KeyGen, introduz o Machine ID e os dias de validade
4. KeyGen gera a chave
5. Cliente introduz a chave → validação offline por tentativa de matching com datas futuras
6. Se válida, grava em `Tbl_Licenca` com DataExpiracao e MachineId

## Versão Demo

- Criada automaticamente na primeira execução
- Duração: 15 dias a partir da instalação
- Limite adicional: 50 vendas
- Ao expirar: sistema bloqueia funcionalidades principais e força ecrã de activação

## Verificações Periódicas

- No arranque da aplicação
- No login
- Antes de aceder a módulos protegidos (PDV, produtos, etc.)

Se a licença estiver inválida ou o MachineId não corresponder (excepto Demo), o sistema impede o uso normal.

## Segurança

- Senhas de utilizadores: BCrypt
- Chaves de licença: HMAC-SHA256 com salt secreto
- Base de dados local (SQLite) em `%LocalAppData%\ECHpro\`
- Machine binding impede cópia simples da licença entre computadores

## Renovação

Para renovar:
1. Cliente envia o Machine ID actual
2. Suporte gera nova chave com nova data de expiração
3. Cliente activa a nova chave (substitui a anterior)

## Contactos de Suporte

- WhatsApp / Telefone: **+258 827473434**
- Email: **ebenchume@sapo.mz**

---

© 2026 Eben Chume
