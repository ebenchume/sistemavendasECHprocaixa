using System.Security.Cryptography;
using System.Text;

namespace ECHpro.KeyGen
{
    internal class Program
    {
        private const string SecretSalt = "ECH-PRO-2026-EBEN-CHUME-MZ-SECRET-KEY-!@#";

        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            Console.WriteLine("═══════════════════════════════════════════════════");
            Console.WriteLine("   ECHpro — Gerador de Chaves de Activação");
            Console.WriteLine("   Desenvolvido por Eben Chume");
            Console.WriteLine("   Contacto: +258 827473434 | ebenchume@sapo.mz");
            Console.WriteLine("═══════════════════════════════════════════════════");
            Console.WriteLine();

            while (true)
            {
                Console.Write("Machine ID do cliente (16 caracteres): ");
                var machineId = Console.ReadLine()?.Trim().ToUpper() ?? "";

                if (string.IsNullOrWhiteSpace(machineId) || machineId.Length < 8)
                {
                    Console.WriteLine("Machine ID inválido. Tente novamente.\n");
                    continue;
                }

                Console.Write("Dias de validade (padrão 365): ");
                var daysStr = Console.ReadLine()?.Trim();
                int days = 365;
                if (!string.IsNullOrEmpty(daysStr) && int.TryParse(daysStr, out var d) && d > 0)
                    days = d;

                var expiration = DateTime.Now.Date.AddDays(days);
                var key = GenerateActivationKey(machineId, expiration, "Anual");

                Console.WriteLine();
                Console.WriteLine("───────────────────────────────────────────────────");
                Console.WriteLine($"  Machine ID : {machineId}");
                Console.WriteLine($"  Validade   : {expiration:dd/MM/yyyy} ({days} dias)");
                Console.WriteLine($"  CHAVE      : {key}");
                Console.WriteLine("───────────────────────────────────────────────────");
                Console.WriteLine();
                Console.WriteLine("Envie esta chave ao cliente juntamente com as instruções.");
                Console.WriteLine();

                Console.Write("Gerar outra chave? (S/N): ");
                var resp = Console.ReadLine()?.Trim().ToUpper();
                if (resp != "S" && resp != "SIM" && resp != "Y")
                    break;
                Console.WriteLine();
            }

            Console.WriteLine("\nObrigado por usar o ECHpro KeyGen.");
        }

        static string GenerateActivationKey(string machineId, DateTime expirationDate, string licenseType = "Anual")
        {
            var payload = $"{machineId.ToUpper()}|{expirationDate:yyyyMMdd}|{licenseType}";
            using var hmac = new HMACSHA256(Encoding.UTF8.GetBytes(SecretSalt));
            var hash = hmac.ComputeHash(Encoding.UTF8.GetBytes(payload));
            var hashStr = BitConverter.ToString(hash).Replace("-", "").Substring(0, 16).ToUpper();
            return $"ECH-{hashStr.Substring(0, 4)}-{hashStr.Substring(4, 4)}-{hashStr.Substring(8, 4)}-{hashStr.Substring(12, 4)}";
        }
    }
}
