# Alterações da v1.1.0

## Erros corrigidos
- **Não compilava**: `App.xaml.cs` importava o namespace inexistente `ECHpro.Helpers`.
- **Vendas ficavam bloqueadas** (~30 s e erro "database is locked"): o número da factura era
  gravado noutra ligação enquanto a transacção da venda estava aberta. Agora o número é atribuído
  dentro da mesma transacção (e também deixa de haver números repetidos).
- A **série da factura** configurada em Configurações era ignorada (usava sempre "FT").
- **Troco entrava na caixa**: valor pago superior ao total é agora limitado ao total.
- Não era possível registar **venda a crédito** (valor 0 era tratado como "pago tudo"). Forma "Crédito" = nada pago.
- **Livro de caixa** nunca preenchia saldo anterior/actual.
- Preços ≥ 1.000 não podiam ser editados (erro de formato decimal em PT). Novo conversor de números.
- Produtos com **IVA 0%** (isentos) passavam a 16% ao guardar.
- Código de produto duplicado fazia a aplicação fechar; agora mostra mensagem.
- Tecla **Delete** no PDV apagava itens mesmo ao escrever em caixas de texto.
- Troco/saldo no PDV era branco sobre branco (invisível); selo "EXPIRADA" também.
- Janela de login sem botão de fechar nem forma de a mover.
- Números nos ecrãs apareciam em formato en-US ("1,234.50") e no resto em formato local.
- Aviso de stock só aparecia com stock zero; agora também se a quantidade excede o stock.
- Limite da demo contornável cancelando vendas; datas de licença em UTC vs hora local;
  licença expirava às 00:00 do último dia (agora ao fim do dia).
- Instalador: `.iss` sem BOM (acentos errados), `Gerar_Instalador.bat`/`build-release.ps1` com
  caracteres que quebravam no Windows PowerShell 5.1; opção Quick Launch obsoleta.

## Melhorias
- Painel principal com dados reais; **Livro de Caixa** e **Relatórios** implementados.
- Vendas: reimprimir factura PDF, **cancelar venda** (repõe stock, anula dívida, estorna caixa), resumo.
- Clientes: **receber pagamento de dívidas** (abate vendas mais antigas), desactivar.
- Produtos: categoria editável, entrada de stock, desactivar, movimento de ajuste ao editar stock.
- Configurações: alterar senha, criar/activar utilizadores, cópia de segurança.
- Cópia de segurança automática diária, integridade referencial activa, índices na base de dados,
  registo de erros em ficheiro, instância única, validações.
- Livro de Caixa e Relatórios só para Admin/Gerente.

## Atenção — licenças
O **ID da máquina deixou de incluir o endereço MAC** (mudava com VPN/USB/Wi-Fi e invalidava a licença).
Por isso o ID mostrado no ecrã de activação pode ser diferente do da versão anterior:
chaves já emitidas para a versão 1.0.0 têm de ser geradas de novo com o novo ID.
