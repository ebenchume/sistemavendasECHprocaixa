# ECHpro v1.1.0 — Sistema de Gestão de Vendas e Faturação

Aplicação WPF (.NET 8) para Windows 10/11 (64 bits). Base de dados SQLite local,
facturas em PDF, controlo de stock, clientes, livro de caixa e licenciamento por máquina.

## Como gerar o instalador (Setup.exe)

No Windows 10/11, com internet:

1. Extraia o projecto para uma pasta (ex.: `C:\ECHpro`).
2. Faça duplo clique em **`Gerar_Instalador.bat`**.
   - Se faltar o .NET SDK 8 ou o Inno Setup 6, o script tenta instalá-los com o `winget`
     (se instalar o .NET, feche a janela e execute o `.bat` outra vez).
3. No fim abre-se a pasta `Installer\Output` com **`ECHpro_Setup_v1.1.0.exe`**.

O instalador inclui o .NET embutido: o PC do cliente não precisa de instalar nada.

Alternativa sem instalar nada no PC: envie o projecto para um repositório GitHub e execute
o workflow **Build Installer** (`.github/workflows/build-installer.yml`); o Setup.exe fica em *Artifacts*.

## Acesso inicial
- Utilizador: `admin` | Senha: `admin123` — **altere a senha** em Configurações > Segurança.
- A versão de demonstração dura 15 dias / 50 vendas. Chaves de licença: projecto `ECHpro.KeyGen`
  (não distribuir aos clientes).

## Dados e cópias de segurança
- Base de dados: `%LocalAppData%\ECHpro\echpro.db`
- Cópia automática diária ao fechar: `%LocalAppData%\ECHpro\Backups` (últimas 10)
- Cópia manual: Configurações > Cópia de Segurança
- Logs de erro: `%LocalAppData%\ECHpro\logs`

## Suporte
Eben Chume — +258 827473434 — ebenchume@sapo.mz
