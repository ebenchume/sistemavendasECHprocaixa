﻿; ECHpro Setup Script - Inno Setup 6
; Versao Self-Contained (.NET 8 embutido) - nao exige instalar nada no PC do cliente.
; Normalmente e compilado pelo Gerar_Instalador.bat (que tambem publica a aplicacao).
; Ficheiro guardado em UTF-8 com BOM (necessario para os acentos no Inno Setup).

#ifndef MyAppVersion
  #define MyAppVersion "1.1.0"
#endif
#define MyAppName "ECHpro"
#define MyAppPublisher "Eben Chume"
#define MyAppURL "https://wa.me/258827473434"
#define MyAppExeName "ECHpro.exe"

; x64compatible so existe a partir do Inno Setup 6.3
#if Ver >= 0x06030000
  #define ArqPermitida "x64compatible"
#else
  #define ArqPermitida "x64"
#endif

[Setup]
AppId={{A8F3C2D1-9E4B-4F6A-8C1D-7B2E5A9F0D3C}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppVerName={#MyAppName} {#MyAppVersion}
AppPublisher={#MyAppPublisher}
AppPublisherURL={#MyAppURL}
AppSupportURL={#MyAppURL}
AppUpdatesURL={#MyAppURL}
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
AllowNoIcons=yes
OutputDir=Output
OutputBaseFilename=ECHpro_Setup_v{#MyAppVersion}
SetupIconFile=..\ECHpro\Assets\echpro.ico
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin
ArchitecturesAllowed={#ArqPermitida}
ArchitecturesInstallIn64BitMode={#ArqPermitida}
MinVersion=10.0
UninstallDisplayIcon={app}\echpro.ico
; Se o ECHpro estiver aberto, o instalador pede para o fechar
AppMutex=ECHproSingleInstanceMutex
CloseApplications=yes
VersionInfoVersion={#MyAppVersion}
VersionInfoCompany={#MyAppPublisher}
VersionInfoDescription=Sistema de Gestão de Vendas e Faturação
VersionInfoCopyright=Copyright (C) 2026 Eben Chume
VersionInfoProductName={#MyAppName}

[Languages]
Name: "portuguese"; MessagesFile: "compiler:Languages\Portuguese.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: checkedonce

[Files]
; Aplicacao publicada (self-contained)
Source: "..\publish\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
; Icone na raiz do app (atalhos e desinstalador)
Source: "..\ECHpro\Assets\echpro.ico"; DestDir: "{app}"; DestName: "echpro.ico"; Flags: ignoreversion

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; IconFilename: "{app}\echpro.ico"; Comment: "Sistema de Gestão de Vendas e Faturação"
Name: "{group}\{cm:UninstallProgram,{#MyAppName}}"; Filename: "{uninstallexe}"; IconFilename: "{app}\echpro.ico"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; IconFilename: "{app}\echpro.ico"; Comment: "ECHpro - Gestão de Vendas"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "{cm:LaunchProgram,{#StringChange(MyAppName, '&', '&&')}}"; Flags: nowait postinstall skipifsilent

[Code]
procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
begin
  if (CurUninstallStep = usPostUninstall) and (not UninstallSilent) then
  begin
    { Por omissao fica "Nao": os dados da loja so sao apagados se o utilizador confirmar }
    if MsgBox('Deseja também remover a base de dados e as cópias de segurança do ECHpro?' + #13#10 +
              '(Estão em %LocalAppData%\ECHpro do utilizador actual)' + #13#10#13#10 +
              'Se vai reinstalar o programa, responda NÃO para manter os seus dados.',
              mbConfirmation, MB_YESNO or MB_DEFBUTTON2) = IDYES then
    begin
      DelTree(ExpandConstant('{localappdata}\ECHpro'), True, True, True);
    end;
  end;
end;
